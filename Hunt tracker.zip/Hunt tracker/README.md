# The Hunt - BL4 Charity Event Tracker 2026

## Distribution Files

Place ALL these files in the **same folder**:

| File | Required | Description |
|------|----------|-------------|
| BL4_Hunt.exe | Yes | The tracker application |
| Hunt_BL4_2026_Tiered.xlsx | Yes | Item list with point values |
| hunt_logo.ico | Yes | App icon (taskbar/title bar) |
| hunt_logo.png | Optional | Logo displayed in app |
| Hunt_Stream_Overlay.html | Optional | OBS/streaming overlay |
| BebasNeue-Regular.ttf | Optional | Custom font (uses Impact if missing) |
| README.md | Optional | These instructions |

---

## Quick Start

1. **Extract all files** to a folder (e.g., `C:\Hunt Tracker\`)
2. **Double-click BL4_Hunt.exe**
3. **Enter your channel name** on first run
4. **Start tracking drops!**

---

## Hotkeys

| Key | Action |
|-----|--------|
| F5 | Record a drop (opens item selector) |
| F6 | Create Twitch/Kick clip of last drop |
| F7 | Quick Log - fast drop entry |

---

## Session Timer

- Click **START** to begin timing your session
- Click **STOP** to pause
- Click **Reset** to clear timer and timestamps
- Drops show elapsed time in the Session column

---

## Stream Overlay Setup (OBS/Streamlabs)

1. In OBS, add a **Browser Source**
2. Check **"Local file"**
3. Browse to `Hunt_Stream_Overlay.html`
4. Set size: **400 x 600** (adjust as needed)
5. The overlay auto-updates when you log drops

The overlay shows:
- Total points
- Drop count  
- Session timer (synced with app)
- Recent drops with slide-in animation

---

## Twitch Clip Integration (Optional)

1. Click **...** (settings button) in the app
2. Click **Connect to Twitch**
3. Authorize in browser
4. Now F6 creates clips automatically!

---

## Tips

- The app saves automatically - your drops persist between sessions
- Use Quick Log (F7) for fast entry during streams
- Export your session via the Export button
- Overlay works without Twitch connection

---

## Troubleshooting

**Antivirus False Positive:**
- Some antivirus programs flag the EXE as suspicious - this is a **false positive**
- The app is compiled from PowerShell using PS2EXE, which some scanners don't recognize
- To fix: Add an exclusion for `BL4_Hunt.exe` or the tracker folder
  - **Windows Defender:** Settings → Virus & threat protection → Exclusions → Add folder
  - **Other AV:** Check your antivirus settings for exclusion/whitelist options
- The source code (`BL4_Hunt_Tracker.ps1`) is fully readable if you want to verify

**"Data file not found" error:**
- Make sure `Hunt_BL4_2026_Tiered.xlsx` is in the same folder as the EXE

**No icon showing:**
- Make sure `hunt_logo.ico` is in the same folder

**Overlay not updating:**
- Check that `hunt_session.json` is being created in the app folder
- Refresh the browser source in OBS

---

## Created By

**Cazif** - Cazif Streaming & Tech Services

For The Hunt 2026 Charity Event
