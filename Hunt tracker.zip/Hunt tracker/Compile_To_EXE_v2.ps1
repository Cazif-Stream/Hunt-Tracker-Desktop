# Compile_To_EXE.ps1 - Compiles Hunt Tracker with execution policy bypass
# Run this script in the same folder as BL4_Hunt_Tracker.ps1

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptPath

# Check for PS2EXE
if (-not (Get-Module -ListAvailable -Name ps2exe)) {
    Write-Host "Installing PS2EXE module..." -ForegroundColor Yellow
    Install-Module -Name ps2exe -Scope CurrentUser -Force
}

Import-Module ps2exe

# Create a wrapper script that bypasses execution policy
$wrapperContent = @'
# Bypass execution policy for module loading
try { Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force -ErrorAction SilentlyContinue } catch {}

# Get the directory where the EXE is located - multiple fallback methods
$scriptDir = $null

# Method 1: PSScriptRoot
if ($PSScriptRoot -and (Test-Path $PSScriptRoot)) {
    $scriptDir = $PSScriptRoot
}

# Method 2: Process path
if (-not $scriptDir) {
    try {
        $exePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        if ($exePath -and (Test-Path $exePath)) {
            $scriptDir = [System.IO.Path]::GetDirectoryName($exePath)
        }
    } catch {}
}

# Method 3: Current directory
if (-not $scriptDir) {
    $scriptDir = Get-Location | Select-Object -ExpandProperty Path
}

# Method 4: Assembly location
if (-not $scriptDir) {
    try {
        $scriptDir = [System.IO.Path]::GetDirectoryName([System.Reflection.Assembly]::GetExecutingAssembly().Location)
    } catch {}
}

# Method 5: AppDomain base
if (-not $scriptDir) {
    try {
        $scriptDir = [System.AppDomain]::CurrentDomain.BaseDirectory.TrimEnd('\')
    } catch {}
}

# Final fallback
if (-not $scriptDir -or -not (Test-Path $scriptDir)) {
    $scriptDir = $PWD.Path
}

# Set location safely
if ($scriptDir -and (Test-Path $scriptDir)) {
    Set-Location $scriptDir
}

# Store for use in script
$script:AppDir = $scriptDir

'@

# Read the original script
$originalScript = Get-Content "BL4_Hunt_Tracker.ps1" -Raw

# Combine wrapper + original script
$combinedScript = $wrapperContent + $originalScript

# Save combined script temporarily
$tempScript = "BL4_Hunt_Tracker_Combined.ps1"
$combinedScript | Set-Content $tempScript -Encoding UTF8

# Compile with icon
$iconPath = Join-Path $scriptPath "hunt_logo.ico"

$compileParams = @{
    InputFile = $tempScript
    OutputFile = "BL4_Hunt.exe"
    NoConsole = $true
    RequireAdmin = $false
    Title = "The Hunt - Charity Event Tracker"
    Description = "Drop tracker for The Hunt charity streaming events (BL2, BL3, BL4)"
    Company = "The Hunt Community"
    Version = "2.0.0"
    Copyright = "2026"
}

if (Test-Path $iconPath) {
    $compileParams.IconFile = $iconPath
    Write-Host "Using icon: $iconPath" -ForegroundColor Green
}

Write-Host "Compiling BL4_Hunt.exe v2.0.0 - Multi-Game Edition..." -ForegroundColor Cyan

try {
    Invoke-PS2EXE @compileParams
    Write-Host ""
    Write-Host "SUCCESS! Created BL4_Hunt.exe (v2.0.0)" -ForegroundColor Green
    Write-Host ""
    
    # Clean up temp file
    Remove-Item $tempScript -Force -ErrorAction SilentlyContinue
    
} catch {
    Write-Host "Compilation failed: $_" -ForegroundColor Red
}

Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
