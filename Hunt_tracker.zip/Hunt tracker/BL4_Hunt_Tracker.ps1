<#
.SYNOPSIS
    The Hunt - Charity Event Tracker
.DESCRIPTION
    Track legendary drops, record clips, and submit scores for The Hunt charity event.
    Supports Borderlands 2, Borderlands 3, and Borderlands 4.
    Features: Drop tracking, Twitch/Kick clip creation, leaderboard submission, OBS integration
.AUTHOR
    Cazif - Cazif Streaming & Tech Services
.VERSION
    2.0.0 - Multi-Game Edition
#>

# Silent logging function - suppresses output in GUI mode (PS2EXE -NoConsole)
function Write-Log {
    param([string]$Message, [string]$ForegroundColor = "White")
    # Only output if console is available (not compiled as GUI)
    if ($Host.Name -eq 'ConsoleHost') {
        try {
            [Console]::WriteLine($Message)
        } catch {}
    }
}

Write-Log "Hunt Tracker v2.0.0 - The Hunt 2026" -ForegroundColor Yellow

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore

#region Script/EXE Path Detection
# Get the directory where the script or EXE is located
# Works for both .ps1 scripts and PS2EXE compiled executables

$script:AppDir = ""

# Collect all possible paths
$possiblePaths = @()

# Method 1: GetExecutingAssembly (works in PS2EXE)
try {
    $asmPath = [System.Reflection.Assembly]::GetExecutingAssembly().Location
    if ($asmPath) { $possiblePaths += [System.IO.Path]::GetDirectoryName($asmPath) }
} catch { }

# Method 2: Process MainModule
try {
    $procPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
    if ($procPath) { $possiblePaths += [System.IO.Path]::GetDirectoryName($procPath) }
} catch { }

# Method 3: BaseDirectory
try {
    $baseDir = [System.AppDomain]::CurrentDomain.BaseDirectory.TrimEnd('\')
    if ($baseDir) { $possiblePaths += $baseDir }
} catch { }

# Method 4: Windows Forms ExecutablePath
try {
    $exePath = [System.Windows.Forms.Application]::ExecutablePath
    if ($exePath) { $possiblePaths += [System.IO.Path]::GetDirectoryName($exePath) }
} catch { }

# Method 5: Command line args
try {
    $cmdArg = [Environment]::GetCommandLineArgs()[0]
    if ($cmdArg -and (Test-Path $cmdArg)) { 
        $possiblePaths += [System.IO.Path]::GetDirectoryName($cmdArg) 
    }
} catch { }

# Method 6: MyInvocation
try {
    if ($MyInvocation.MyCommand.Path) {
        $possiblePaths += Split-Path -Parent $MyInvocation.MyCommand.Path
    }
} catch { }

# Method 7: PSScriptRoot
if ($PSScriptRoot) { $possiblePaths += $PSScriptRoot }

# Method 8: Current directory
$possiblePaths += [System.IO.Directory]::GetCurrentDirectory()
$possiblePaths += (Get-Location).Path

# Find the best path - one that contains our xlsx file or is not system/temp
foreach ($path in $possiblePaths) {
    if (-not $path -or $path -eq "" -or $path.Length -lt 3) { continue }
    
    # Skip system paths
    if ($path -match 'Windows\\System32|Windows\\SysWOW64|powershell|pwsh') { continue }
    
    # Check if xlsx exists here - best indicator
    $testFile = Join-Path $path "Hunt_BL4_2026_Tiered.xlsx"
    if (Test-Path $testFile) {
        $script:AppDir = $path
        break
    }
}

# If no xlsx found, use first valid non-system path
if (-not $script:AppDir -or $script:AppDir -eq "") {
    foreach ($path in $possiblePaths) {
        if (-not $path -or $path -eq "" -or $path.Length -lt 3) { continue }
        if ($path -match 'Windows\\System32|Windows\\SysWOW64|powershell|pwsh') { continue }
        if (Test-Path $path) {
            $script:AppDir = $path
            break
        }
    }
}

# Final fallback
if (-not $script:AppDir -or $script:AppDir -eq "") {
    $script:AppDir = [System.IO.Directory]::GetCurrentDirectory()
}

# CRITICAL: Change working directory to where the EXE/script is located
# This ensures all relative file paths work correctly
try {
    Set-Location $script:AppDir
    [System.IO.Directory]::SetCurrentDirectory($script:AppDir)
} catch { }

Write-Log "App directory: $($script:AppDir)" -ForegroundColor Cyan
#endregion

#region Custom Font Loading
# Load Bebas Neue font if available (free from Google Fonts)
$script:FontCollection = New-Object System.Drawing.Text.PrivateFontCollection
$script:CustomFonts = @{}
$script:HasCustomFonts = $false

# Font files to look for
$fontFiles = @(
    @{ Name = "Bebas Neue"; Files = @("BebasNeue-Regular.ttf", "BebasNeue.ttf", "Bebas-Neue.ttf", "bebas-neue.ttf") }
)

Write-Log ""
Write-Log "Loading Hunt fonts..." -ForegroundColor Cyan

foreach ($fontDef in $fontFiles) {
    foreach ($fileName in $fontDef.Files) {
        $fontPath = "$script:AppDir\$fileName"
        if (Test-Path $fontPath) {
            try {
                $script:FontCollection.AddFontFile($fontPath)
                $script:HasCustomFonts = $true
                $loadedFamily = $script:FontCollection.Families | Select-Object -Last 1
                $script:CustomFonts[$fontDef.Name] = $loadedFamily
                Write-Log "  [OK] $($fontDef.Name)" -ForegroundColor Green
                break
            } catch {
                Write-Log "  [!] Could not load $fileName" -ForegroundColor Yellow
            }
        }
    }
}

# Also check a "fonts" subfolder
$fontsFolder = "$script:AppDir\fonts"
if (Test-Path $fontsFolder) {
    Get-ChildItem -Path $fontsFolder -Filter "*.ttf" | ForEach-Object {
        try {
            $script:FontCollection.AddFontFile($_.FullName)
            $script:HasCustomFonts = $true
            $familyName = ($script:FontCollection.Families | Select-Object -Last 1).Name
            $script:CustomFonts[$familyName] = $script:FontCollection.Families | Select-Object -Last 1
            Write-Log "  [OK] $familyName (from fonts folder)" -ForegroundColor Green
        } catch {}
    }
}

if (-not $script:HasCustomFonts) {
    Write-Log "  No custom fonts found. Using Impact." -ForegroundColor Yellow
    Write-Log "  Download Bebas Neue from: https://fonts.google.com/specimen/Bebas+Neue" -ForegroundColor Cyan
}
Write-Log ""

# Helper function to get the display font (titles, scores, buttons)
function Get-HuntFont {
    param(
        [float]$Size = 10,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )
    
    # Apply UI scale
    $scaledSize = $Size * $script:Config.UIScale
    
    # Try Bebas Neue first
    if ($script:CustomFonts.ContainsKey("Bebas Neue")) {
        try {
            return New-Object System.Drawing.Font($script:CustomFonts["Bebas Neue"], $scaledSize, $Style)
        } catch {}
    }
    
    # Try any loaded custom font
    if ($script:FontCollection.Families.Count -gt 0) {
        try {
            return New-Object System.Drawing.Font($script:FontCollection.Families[0], $scaledSize, $Style)
        } catch {}
    }
    
    # Fallback: Impact
    return New-Object System.Drawing.Font("Impact", $scaledSize, $Style)
}

# Regular UI font (not display)
function Get-UIFont {
    param(
        [float]$Size = 9,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )
    # Apply UI scale
    $scaledSize = $Size * $script:Config.UIScale
    return New-Object System.Drawing.Font("Segoe UI", $scaledSize, $Style)
}
#endregion

#region Configuration
# ============================================================================
# EVENT ORGANIZER SETUP
# ============================================================================
# Before distributing this tool to participants:
# 1. Go to https://dev.twitch.tv/console/apps
# 2. Create a new application called "The Hunt BL4 2026"
# 3. Set OAuth Redirect URL to: http://localhost:3000/callback
# 4. Copy the Client ID and paste it below
# 5. Save this file and distribute to participants
# ============================================================================

$script:Config = @{
    # File paths
    DataFile = "$script:AppDir\Hunt_BL4_2026_Tiered.xlsx"
    SessionFile = "$script:AppDir\hunt_session.json"
    SettingsFile = "$script:AppDir\hunt_settings.json"
    
    # Hotkeys
    RecordDropKey = [System.Windows.Forms.Keys]::F5
    CreateClipKey = [System.Windows.Forms.Keys]::F6
    QuickLogKey = [System.Windows.Forms.Keys]::F7
    
    # UVHM Level (0 = NVHM, 1-6 = UVHM levels)
    UVHMLevel = 0
    
    # =========================================
    # TWITCH API - SET YOUR CLIENT ID HERE!
    # =========================================
    TwitchClientId = "c2bgw33qxa6dbx0dyazbzi0yap4vnk"  # Hunt Tracker App Client ID
    TwitchAccessToken = ""  # Filled automatically when user connects
    TwitchChannelName = ""  # Filled automatically when user connects
    
    # Kick API  
    KickChannelName = ""
    KickStreamKey = ""
    
    # Clip Settings
    ClipDelay = 30  # Seconds to capture before clip
    AutoClipOnDrop = $false
    
    # UI Settings
    UIScale = 1.0  # 1.0 = normal, 1.25 = large, 1.5 = extra large
    
    # Theme
    DarkMode = $true

    # Multi-Game Support
    SelectedGame = "BL4"
    GameDataFiles = @{
        BL2 = "All Aboard BL2 Hunt Item list.xlsx"
        BL3 = "All Aboard BL3 Hunt List.xlsx"
        BL4 = "Hunt_BL4_2026_Tiered.xlsx"
    }
    GameLabels = @{
        BL2 = "Borderlands 2"
        BL3 = "Borderlands 3"
        BL4 = "Borderlands 4"
    }
}

$script:Theme = @{
    Dark = @{
        Background = [System.Drawing.Color]::FromArgb(66, 4, 21)         # #420415 Dark maroon
        Surface = [System.Drawing.Color]::FromArgb(152, 10, 49)          # #980a31 Maroon
        Primary = [System.Drawing.Color]::FromArgb(255, 198, 0)          # #ffc600 Bright gold
        Secondary = [System.Drawing.Color]::FromArgb(255, 248, 166)      # #fff8a6 Light yellow
        Text = [System.Drawing.Color]::White                              # #ffffff
        TextMuted = [System.Drawing.Color]::FromArgb(255, 248, 166)      # Light yellow
        Success = [System.Drawing.Color]::FromArgb(255, 198, 0)          # Gold for success
        Warning = [System.Drawing.Color]::FromArgb(255, 152, 0)
        Border = [System.Drawing.Color]::FromArgb(255, 198, 0)           # Gold border
        Gold = [System.Drawing.Color]::FromArgb(255, 198, 0)             # Bright gold
    }
    Light = @{
        Background = [System.Drawing.Color]::FromArgb(255, 248, 240)
        Surface = [System.Drawing.Color]::White
        Primary = [System.Drawing.Color]::FromArgb(152, 10, 49)          # Maroon
        Secondary = [System.Drawing.Color]::FromArgb(255, 198, 0)        # Gold
        Text = [System.Drawing.Color]::FromArgb(66, 4, 21)
        TextMuted = [System.Drawing.Color]::FromArgb(100, 80, 80)
        Success = [System.Drawing.Color]::FromArgb(46, 125, 50)
        Warning = [System.Drawing.Color]::FromArgb(230, 126, 34)
        Border = [System.Drawing.Color]::FromArgb(180, 150, 150)
        Gold = [System.Drawing.Color]::FromArgb(255, 198, 0)
    }
}
#endregion

#region Simple Point System
# The Hunt 2026 uses a simple point system:
# - Most items: 1 point (Legendary)
# - Pearl items: 5 points (Rare)

function Get-PointsDisplay {
    param([int]$Points)
    
    if ($Points -ge 5) {
        return "$Points pts (PEARL)"
    }
    return "$Points pt"
}
#endregion

#region Global Variables
$script:BossDrops = @()
$script:WorldDrops = @()
$script:Session = @{
    PlayerName = ""
    StartTime = $null
    Drops = @()
    TotalScore = 0
    ClipLinks = @()
}
$script:IsTracking = $false
$script:FirstLaunchComplete = $true  # Disabled - no longer needed
$script:SilentLoad = $true  # Suppress popups during initial load

# Session Timer
$script:SessionTimerRunning = $false
$script:SessionTimerStart = $null
$script:SessionAccumulatedTime = [TimeSpan]::Zero
$script:saveCallCount = 0
$script:cachedSessionJson = $null
$script:sessionDataDirty = $true
$script:gcCounter = 0

# Splash Screen
$script:SplashForm = $null
function Show-SplashScreen {
    $script:SplashForm = New-Object System.Windows.Forms.Form
    $script:SplashForm.Size = New-Object System.Drawing.Size(400, 200)
    $script:SplashForm.StartPosition = 'CenterScreen'
    $script:SplashForm.FormBorderStyle = 'None'
    $script:SplashForm.BackColor = [System.Drawing.Color]::FromArgb(66, 4, 21)
    $script:SplashForm.TopMost = $true
    
    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text = "THE HUNT 2026"
    $lblTitle.Font = New-Object System.Drawing.Font("Impact", 28, [System.Drawing.FontStyle]::Regular)
    $lblTitle.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    $lblTitle.AutoSize = $true
    $lblTitle.Location = New-Object System.Drawing.Point(80, 40)
    
    $script:lblStatus = New-Object System.Windows.Forms.Label
    $script:lblStatus.Text = "Loading..."
    $script:lblStatus.Font = New-Object System.Drawing.Font("Segoe UI", 12)
    $script:lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(255, 248, 166)
    $script:lblStatus.AutoSize = $true
    $script:lblStatus.Location = New-Object System.Drawing.Point(150, 120)
    
    $script:SplashForm.Controls.AddRange(@($lblTitle, $script:lblStatus))
    $script:SplashForm.Show()
    $script:SplashForm.Refresh()
}

function Update-SplashStatus {
    param([string]$Status)
    if ($script:lblStatus) {
        $script:lblStatus.Text = $Status
        $script:SplashForm.Refresh()
    }
}

function Close-SplashScreen {
    if ($script:SplashForm) {
        $script:SplashForm.Close()
        $script:SplashForm.Dispose()
        $script:SplashForm = $null
    }
}
#endregion

#region Data Loading Functions
function Import-HuntData {
    param([string]$FilePath)
    
    if (-not (Test-Path $FilePath)) {
        if (-not $script:SilentLoad) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "Hunt data file not found: $FilePath`n`nPlease place the hunt data xlsx file in the same folder as this app.",
                "Data File Missing",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
        }
        return $false
    }
    
    try {
        # Check if ImportExcel module is available
        $moduleAvailable = Get-Module -ListAvailable -Name ImportExcel
        
        if (-not $moduleAvailable) {
            if ($script:SilentLoad) {
                # Try to install silently during initial load
                try {
                    Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                }
                catch {
                    return $false
                }
            }
            else {
                # Prompt to install ImportExcel module
                $installChoice = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                    "The ImportExcel module is required to read the hunt data.`n`nWould you like to install it now?`n`n(This is a one-time setup)",
                    "Module Required",
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Question
                )
                
                if ($installChoice -eq 'Yes') {
                    try {
                        Write-Log "Installing ImportExcel module..." -ForegroundColor Cyan
                        
                        # Install for current user (doesn't require admin)
                        Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber
                        
                        [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                            "ImportExcel module installed successfully!`n`nThe tracker will now load.",
                            "Success",
                            [System.Windows.Forms.MessageBoxButtons]::OK,
                            [System.Windows.Forms.MessageBoxIcon]::Information
                        )
                    }
                    catch {
                        [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                            "Failed to install ImportExcel module automatically.`n`nPlease open PowerShell and run:`nInstall-Module -Name ImportExcel -Scope CurrentUser -Force`n`nThen restart the tracker.",
                            "Installation Failed",
                            [System.Windows.Forms.MessageBoxButtons]::OK,
                            [System.Windows.Forms.MessageBoxIcon]::Error
                        )
                        return $false
                    }
                }
                else {
                    [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                        "Cannot load hunt data without ImportExcel module.`n`nTo install manually, open PowerShell and run:`nInstall-Module -Name ImportExcel -Scope CurrentUser -Force",
                        "Module Required",
                        [System.Windows.Forms.MessageBoxButtons]::OK,
                        [System.Windows.Forms.MessageBoxIcon]::Warning
                    )
                    return $false
                }
            }
        }
        
        # Import the module
        Import-Module ImportExcel -Force -ErrorAction Stop
        
        # Read hunt data sheet
        Write-Log "Loading hunt data from: $FilePath" -ForegroundColor Cyan

        # Try "Master Boss Drops" sheet with headers (BL4 format)
        # Fall back to NoHeader mode for BL2/BL3 (they have duplicate/empty column headers)
        $bossRawData = $null
        $worldRawData = @()
        $useHeaders = $true

        try {
            $bossRawData = Import-Excel -Path $FilePath -WorksheetName "Master Boss Drops" -StartRow 3
            Write-Log "Using sheet: 'Master Boss Drops' (header mode)" -ForegroundColor Cyan
        } catch {
            # BL2/BL3: use first sheet, NoHeader mode (duplicate headers in these files)
            $useHeaders = $false
            $bossRawData = Import-Excel -Path $FilePath -NoHeader -StartRow 4
            Write-Log "Using first sheet (NoHeader mode for BL2/BL3)" -ForegroundColor Cyan
        }

        # Try to load world drops sheet if it exists
        try {
            $worldRawData = Import-Excel -Path $FilePath -WorksheetName "World Drops " -StartRow 3
        } catch { $worldRawData = @() }

        # Process drops data
        $bossData = @()

        if ($useHeaders) {
            # BL4 format: use column header names
            foreach ($row in $bossRawData) {
                $itemName = $row.'Item name'
                if (-not $itemName) { $itemName = $row.'Item Name' }
                if (-not $itemName) { $itemName = $row.Name }
                if (-not $itemName) { $itemName = $row.ItemName }

                if ([string]::IsNullOrWhiteSpace($itemName)) { continue }

                $pts = 1.0
                if ($row.Pts) {
                    try { $pts = [double]$row.Pts } catch { $pts = 1.0 }
                }

                $bossName = ""
                if ($row.'Boss Name') { $bossName = $row.'Boss Name' }
                elseif ($row.BossName) { $bossName = $row.BossName }

                $gameMode = "NVHM"
                if ($row.'Game mode') { $gameMode = $row.'Game mode' }
                elseif ($row.'Game Mode') { $gameMode = $row.'Game Mode' }

                $bossData += [PSCustomObject]@{
                    Points = $pts
                    ItemName = "$itemName".Trim()
                    GameMode = "$gameMode".Trim()
                    BossName = "$bossName".Trim()
                    Mission = if ($row.Mission) { "$($row.Mission)".Trim() } else { "" }
                    Manufacturer = if ($row.Manufacturer) { "$($row.Manufacturer)".Trim() } else { "" }
                    Type = if ($row.Type) { "$($row.Type)".Trim() } else { "" }
                    DropRate = if ($row.'Drop Rate %') { $row.'Drop Rate %' } elseif ($row.DropRate) { $row.DropRate } else { "" }
                    HasShiny = if ($row.'Has Shiny?') { $row.'Has Shiny?' } elseif ($row.HasShiny) { $row.HasShiny } else { "No" }
                    Notes = if ($row.Notes) { $row.Notes } else { "" }
                    Claimed = $false
                }
            }
        } else {
            # BL2/BL3 format: NoHeader mode, columns are P1, P2, P3...
            # Both games share: P3=Pts, P4=Name, P5=Type
            # BL2: P8=Source/Boss, P10=Mission
            # BL3: P10=Source/Boss, P12=Mission
            # Detect which format by checking if P8 looks like a boss name
            foreach ($row in $bossRawData) {
                $itemName = $row.P4
                if ([string]::IsNullOrWhiteSpace($itemName)) { continue }

                $pts = 1.0
                if ($row.P3) {
                    try { $pts = [double]$row.P3 } catch { $pts = 1.0 }
                }

                # Determine boss column: BL2 has boss in P8, BL3 has boss in P10
                # BL2's P8 is "Source 1" (boss), BL3's P8 is "Ofc List" (number)
                $bossName = ""
                $mission = ""
                if ($row.P8 -and $row.P8 -match '^\d+\.?\d*$') {
                    # P8 is numeric = BL3 format (Ofc List is a number)
                    $bossName = if ($row.P10) { "$($row.P10)" } else { "" }
                    $mission = if ($row.P12) { "$($row.P12)" } else { "" }
                } else {
                    # P8 is text = BL2 format (Source 1 is boss name)
                    $bossName = if ($row.P8) { "$($row.P8)" } else { "" }
                    $mission = if ($row.P10) { "$($row.P10)" } else { "" }
                }

                $bossData += [PSCustomObject]@{
                    Points = $pts
                    ItemName = "$itemName".Trim()
                    GameMode = "NVHM"
                    BossName = "$bossName".Trim()
                    Mission = "$mission".Trim()
                    Manufacturer = ""
                    Type = if ($row.P5) { "$($row.P5)".Trim() } else { "" }
                    DropRate = ""
                    HasShiny = "No"
                    Notes = ""
                    Claimed = $false
                }
            }
        }

        # Process World Drops (BL4 only - BL2/BL3 don't have this sheet)
        $worldData = @()
        foreach ($row in $worldRawData) {
            $itemName = $row.'Legendary Item'
            if (-not $itemName) { $itemName = $row.'Item Name' }
            if (-not $itemName) { $itemName = $row.Name }
            if (-not $itemName) { $itemName = $row.ItemName }

            if ([string]::IsNullOrWhiteSpace($itemName)) { continue }

            $worldData += [PSCustomObject]@{
                Source = if ($row.Source) { $row.Source } else { "World Drop" }
                ItemName = $itemName
                Manufacturer = if ($row.Manufacturer) { $row.Manufacturer } else { "" }
                Type = if ($row.Type) { $row.Type } else { "" }
                DropTier = if ($row.'Drop Tier') { $row.'Drop Tier' } else { "" }
                HasShiny = if ($row.'Has Shiny?') { $row.'Has Shiny?' } else { "No" }
                Notes = if ($row.Notes) { $row.Notes } else { "" }
                Claimed = $false
            }
        }

        $script:BossDrops = $bossData
        $script:WorldDrops = $worldData

        Write-Log "Loaded $($bossData.Count) boss drops and $($worldData.Count) world drops" -ForegroundColor Green
        
        return $true
    }
    catch {
        if (-not $script:SilentLoad) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "Error loading hunt data: $($_.Exception.Message)",
                "Load Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
        }
        return $false
    }
}

function Import-XlsxManual {
    param([string]$FilePath)
    
    # XLSX files are ZIP archives containing XML
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    
    $tempDir = Join-Path $env:TEMP "HuntTracker_$(Get-Random)"
    
    try {
        # Extract xlsx
        [System.IO.Compression.ZipFile]::ExtractToDirectory($FilePath, $tempDir)
        
        # Load shared strings (text values are stored separately)
        $sharedStringsPath = Join-Path $tempDir "xl\sharedStrings.xml"
        [string[]]$sharedStrings = @()
        if (Test-Path $sharedStringsPath) {
            [xml]$ssXml = Get-Content $sharedStringsPath -Encoding UTF8
            $ns = @{x = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            $tempStrings = @($ssXml.sst.si | ForEach-Object {
                if ($_.t) { 
                    if ($_.t.'#text') { $_.t.'#text' } else { $_.t }
                } 
                elseif ($_.r) { 
                    ($_.r.t | ForEach-Object { if ($_.'#text') { $_.'#text' } else { $_ } }) -join '' 
                }
                else { "" }
            })
            if ($tempStrings) { $sharedStrings = $tempStrings }
        }
        
        # Load workbook to get sheet names
        [xml]$workbookXml = Get-Content (Join-Path $tempDir "xl\workbook.xml") -Encoding UTF8
        $nsWb = @{x = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        
        # Find sheet IDs
        $sheets = @{}
        $workbookXml.workbook.sheets.sheet | ForEach-Object {
            $sheets[$_.name] = $_.sheetId
        }
        
        # Parse Boss Drops sheet (sheet1)
        $bossSheetPath = Join-Path $tempDir "xl\worksheets\sheet1.xml"
        if (Test-Path $bossSheetPath) {
            $script:BossDrops = Parse-SheetData -SheetPath $bossSheetPath -SharedStrings $sharedStrings -StartRow 4 -Type "Boss"
            Write-Log "Loaded $($script:BossDrops.Count) boss drops" -ForegroundColor Green
            
            # Show tier distribution
            $tierCounts = @{ Primary = 0; Secondary = 0; Tertiary = 0 }
            foreach ($item in $script:BossDrops) {
                $t = $item.DropTier
                if ($tierCounts.ContainsKey($t)) { $tierCounts[$t]++ }
            }
            Write-Log "Tier distribution: Primary=$($tierCounts['Primary']), Secondary=$($tierCounts['Secondary']), Tertiary=$($tierCounts['Tertiary'])" -ForegroundColor Green
        }
        
        # Parse World Drops sheet (sheet2)
        $worldSheetPath = Join-Path $tempDir "xl\worksheets\sheet2.xml"
        if (Test-Path $worldSheetPath) {
            $script:WorldDrops = Parse-SheetData -SheetPath $worldSheetPath -SharedStrings $sharedStrings -StartRow 4 -Type "World"
        }
        
        return $true
    }
    catch {
        throw $_
    }
    finally {
        # Cleanup
        if (Test-Path $tempDir) {
            Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Parse-SheetData {
    param(
        [string]$SheetPath,
        [string[]]$SharedStrings,
        [int]$StartRow = 4,
        [string]$Type = "Boss"
    )
    
    [xml]$sheetXml = Get-Content $SheetPath -Encoding UTF8
    $ns = @{x = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    
    $results = @()
    
    foreach ($row in $sheetXml.worksheet.sheetData.row) {
        $rowNum = [int]$row.r
        if ($rowNum -lt $StartRow) { continue }
        
        # Build cell dictionary for this row
        $cells = @{}
        foreach ($cell in $row.c) {
            $colLetter = ($cell.r -replace '[0-9]', '')
            $value = ""
            
            if ($cell.t -eq "s" -and $cell.v) {
                # Shared string reference
                $idx = [int]$cell.v
                if ($null -ne $SharedStrings -and $SharedStrings.Count -gt 0 -and $idx -lt $SharedStrings.Count) {
                    $value = $SharedStrings[$idx]
                }
            }
            elseif ($cell.t -eq "inlineStr") {
                # Inline string - get text from <is><t> element
                if ($cell.is -and $cell.is.t) {
                    $value = if ($cell.is.t.'#text') { $cell.is.t.'#text' } else { $cell.is.t }
                } else {
                    $value = $cell.InnerText
                }
            }
            elseif ($cell.v) {
                $value = $cell.v
            }
            
            $cells[$colLetter] = $value
        }
        
        if ($Type -eq "Boss") {
            # Boss sheet: C=Pts, D=ItemName, E=GameMode, F=BossName, G=Mission, H=Manufacturer, I=Type, J=DropRate%, K=HasShiny, L=Notes
            $itemName = $cells["D"]
            if (-not [string]::IsNullOrWhiteSpace($itemName)) {
                # Column J contains drop rate percentage
                $dropRate = $cells["J"]
                
                # Determine tier from base rate percentage
                # UVHM 0 rates: Primary=9%, Secondary=6%, Tertiary=3%
                $dropTier = "Secondary"  # Default
                
                if ($dropRate) {
                    # Remove % and any whitespace
                    $rateStr = $dropRate.ToString() -replace '[%\s]', ''
                    
                    # Debug first 10 items
                    if ($rowNum -le 13) {
                        Write-Log "Row $rowNum '$itemName': Raw='$dropRate', Cleaned='$rateStr'" -ForegroundColor Cyan
                    }
                    
                    if ($rateStr -match '^\d+\.?\d*$') {
                        $rateVal = [double]$rateStr
                        # Handle decimals like 0.09
                        if ($rateVal -lt 1 -and $rateVal -gt 0) { 
                            $rateVal = $rateVal * 100 
                        }
                        
                        # Assign tier based on rate
                        if ($rateVal -ge 8) { 
                            $dropTier = "Primary" 
                        }
                        elseif ($rateVal -ge 5) { 
                            $dropTier = "Secondary" 
                        }
                        else { 
                            $dropTier = "Tertiary" 
                        }
                        
                        if ($rowNum -le 13) {
                            Write-Log "  -> Rate=$rateVal, Tier=$dropTier" -ForegroundColor Green
                        }
                    }
                }
                
                $results += [PSCustomObject]@{
                    Points = if ($cells["C"]) { try { [double]$cells["C"] } catch { 1.0 } } else { 1.0 }
                    ItemName = $itemName
                    GameMode = $cells["E"]
                    BossName = $cells["F"]
                    Mission = $cells["G"]
                    Manufacturer = $cells["H"]
                    Type = $cells["I"]
                    DropTier = $dropTier
                    HasShiny = $cells["K"]
                    Notes = $cells["L"]
                    Claimed = $false
                }
            }
        }
        else {
            # World sheet: A=Source, B=ItemName, C=Manufacturer, D=Type, E=DropTier, F=DropRate, G=HasShiny, etc
            $itemName = $cells["B"]
            if (-not [string]::IsNullOrWhiteSpace($itemName)) {
                $results += [PSCustomObject]@{
                    Source = $cells["A"]
                    ItemName = $itemName
                    Manufacturer = $cells["C"]
                    Type = $cells["D"]
                    DropTier = $cells["E"]
                    HasShiny = $cells["G"]
                    Notes = $cells["K"]
                    Claimed = $false
                }
            }
        }
    }
    
    return $results
}

function Import-SessionData {
    if (Test-Path $script:Config.SessionFile) {
        try {
            # Retry reading in case file is being written
            $json = $null
            for ($retry = 0; $retry -lt 3; $retry++) {
                try {
                    $json = [System.IO.File]::ReadAllText($script:Config.SessionFile, [System.Text.Encoding]::UTF8)
                    break
                }
                catch {
                    if ($retry -lt 2) { Start-Sleep -Milliseconds 100 }
                }
            }
            if (-not $json) { return $false }
            
            $data = $json | ConvertFrom-Json
            $script:Session = @{
                PlayerName = if ($data.PlayerName) { $data.PlayerName } else { "" }
                StartTime = if ($data.StartTime) { [DateTime]::Parse($data.StartTime) } else { $null }
                Drops = @($data.Drops | Where-Object { $_ })
                TotalScore = if ($data.TotalScore) { [int]$data.TotalScore } else { 0 }
                ClipLinks = @($data.ClipLinks | Where-Object { $_ })
            }
            
            # Ensure all drops have Submitted property (backward compat)
            for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                if ($null -eq $script:Session.Drops[$i].Submitted) {
                    $script:Session.Drops[$i] | Add-Member -NotePropertyName "Submitted" -NotePropertyValue $false -Force
                }
            }
            
            # Restore timer state - handle both int and TimeSpan object formats
            $timerSecs = 0
            if ($data.TimerSeconds) {
                if ($data.TimerSeconds -is [int] -or $data.TimerSeconds -is [double]) {
                    $timerSecs = [int]$data.TimerSeconds
                } elseif ($data.TimerSeconds.TotalSeconds) {
                    $timerSecs = [int]$data.TimerSeconds.TotalSeconds
                }
            }
            if ($timerSecs -gt 0) {
                $script:SessionAccumulatedTime = [TimeSpan]::FromSeconds($timerSecs)
            }
            
            Write-Log "Loaded session: $($script:Session.Drops.Count) drops, $($script:Session.TotalScore) pts" -ForegroundColor Green
            return $true
        }
        catch {
            Write-Log "Could not load session: $($_.Exception.Message)" -ForegroundColor Red
            return $false
        }
    }
    return $false
}

function Save-SessionData {
    try {
        # Calculate current timer seconds
        [int]$timerSeconds = 0
        if ($script:SessionTimerRunning -and $script:SessionTimerStart) {
            $currentElapsed = ([datetime]::Now - $script:SessionTimerStart).TotalSeconds
            $accumulated = 0
            if ($script:SessionAccumulatedTime -and $script:SessionAccumulatedTime -is [TimeSpan]) {
                $accumulated = $script:SessionAccumulatedTime.TotalSeconds
            }
            $timerSeconds = [int]($accumulated + $currentElapsed)
        } elseif ($script:SessionAccumulatedTime -and $script:SessionAccumulatedTime -is [TimeSpan]) {
            $timerSeconds = [int]$script:SessionAccumulatedTime.TotalSeconds
        }
        
        # Only rebuild full JSON when data changes (drops/clips/score)
        # Timer-only updates use cached JSON with updated timer values
        if ($script:sessionDataDirty -or -not $script:cachedSessionJson) {
            $dropsArray = @()
            if ($script:Session.Drops) { $dropsArray = @($script:Session.Drops) }
            
            $saveData = @{
                PlayerName = $script:Session.PlayerName
                SelectedGame = $script:Config.SelectedGame
                StartTime = if ($script:Session.StartTime) { $script:Session.StartTime.ToString("o") } else { $null }
                Drops = $dropsArray
                TotalScore = [int]$script:Session.TotalScore
                DropsFound = @($script:Session.Drops).Count
                TotalItems = $script:BossDrops.Count
                DropsLeft = [Math]::Max(0, $script:BossDrops.Count - @($script:Session.Drops).Count)
                ClipLinks = @($script:Session.ClipLinks)
                LastSaved = (Get-Date).ToString("o")
                TimerRunning = [bool]$script:SessionTimerRunning
                TimerSeconds = $timerSeconds
            }
            $script:cachedSessionJson = $saveData | ConvertTo-Json -Depth 10
            $script:sessionDataDirty = $false
        } else {
            # Lightweight update - just swap timer values in cached JSON (no ConvertTo-Json)
            $script:cachedSessionJson = $script:cachedSessionJson -replace '"TimerSeconds":\s*\d+', "`"TimerSeconds`": $timerSeconds"
            $script:cachedSessionJson = $script:cachedSessionJson -replace '"TimerRunning":\s*(true|false)', "`"TimerRunning`": $($script:SessionTimerRunning.ToString().ToLower())"
            $script:cachedSessionJson = $script:cachedSessionJson -replace '"LastSaved":\s*"[^"]*"', "`"LastSaved`": `"$((Get-Date).ToString('o'))`""
        }
        
        # Simple direct write with retry
        for ($retry = 0; $retry -lt 3; $retry++) {
            try {
                [System.IO.File]::WriteAllText($script:Config.SessionFile, $script:cachedSessionJson, [System.Text.Encoding]::UTF8)
                break
            }
            catch {
                if ($retry -lt 2) { Start-Sleep -Milliseconds 50 }
            }
        }
    }
    catch {
        # Silently fail - don't crash for a sync issue
    }
}

function Import-Settings {
    if (Test-Path $script:Config.SettingsFile) {
        try {
            $settings = Get-Content $script:Config.SettingsFile -Raw | ConvertFrom-Json
            
            if ($settings.TwitchClientId) { $script:Config.TwitchClientId = $settings.TwitchClientId }
            if ($settings.TwitchAccessToken) { $script:Config.TwitchAccessToken = $settings.TwitchAccessToken }
            if ($settings.TwitchChannelName) { $script:Config.TwitchChannelName = $settings.TwitchChannelName }
            if ($settings.KickChannelName) { $script:Config.KickChannelName = $settings.KickChannelName }
            if ($settings.KickStreamKey) { $script:Config.KickStreamKey = $settings.KickStreamKey }
            if ($null -ne $settings.ClipDelay) { $script:Config.ClipDelay = $settings.ClipDelay }
            if ($null -ne $settings.AutoClipOnDrop) { $script:Config.AutoClipOnDrop = $settings.AutoClipOnDrop }
            if ($null -ne $settings.DarkMode) { $script:Config.DarkMode = $settings.DarkMode }
            if ($null -ne $settings.UVHMLevel) { $script:Config.UVHMLevel = $settings.UVHMLevel }
            if ($null -ne $settings.UIScale) { $script:Config.UIScale = $settings.UIScale }
            if ($null -ne $settings.FirstLaunchComplete) { $script:FirstLaunchComplete = $settings.FirstLaunchComplete }
            if ($settings.SelectedGame) { $script:Config.SelectedGame = $settings.SelectedGame }
            
            # Hotkeys
            if ($settings.RecordDropKey) { $script:Config.RecordDropKey = [System.Windows.Forms.Keys]$settings.RecordDropKey }
            if ($settings.CreateClipKey) { $script:Config.CreateClipKey = [System.Windows.Forms.Keys]$settings.CreateClipKey }
            if ($settings.QuickLogKey) { $script:Config.QuickLogKey = [System.Windows.Forms.Keys]$settings.QuickLogKey }
        }
        catch {
            Write-Log "Could not load settings: $($_.Exception.Message)"
        }
    }
}

function Save-Settings {
    try {
        $settings = @{
            TwitchClientId = $script:Config.TwitchClientId
            TwitchAccessToken = $script:Config.TwitchAccessToken
            TwitchChannelName = $script:Config.TwitchChannelName
            KickChannelName = $script:Config.KickChannelName
            KickStreamKey = $script:Config.KickStreamKey
            ClipDelay = $script:Config.ClipDelay
            AutoClipOnDrop = $script:Config.AutoClipOnDrop
            DarkMode = $script:Config.DarkMode
            UVHMLevel = $script:Config.UVHMLevel
            UIScale = $script:Config.UIScale
            FirstLaunchComplete = $script:FirstLaunchComplete
            SelectedGame = $script:Config.SelectedGame
            RecordDropKey = $script:Config.RecordDropKey.ToString()
            CreateClipKey = $script:Config.CreateClipKey.ToString()
            QuickLogKey = $script:Config.QuickLogKey.ToString()
        }
        $settings | ConvertTo-Json | Set-Content $script:Config.SettingsFile -Encoding UTF8
    }
    catch {
        Write-Log "Error saving settings: $($_.Exception.Message)"
    }
}
#endregion

#region Twitch OAuth Functions
function Show-TwitchPrivacyNotice {
    <#
    .SYNOPSIS
        Shows privacy notice before Twitch OAuth connection
    .DESCRIPTION
        Explains what data is accessed and stored to address privacy concerns
    #>
    
    $privacyText = @"
PRIVACY NOTICE - Twitch Connection

What happens when you connect:
- You'll log in directly on Twitch's website (not ours)
- We NEVER see or store your Twitch password
- Twitch sends us a temporary access token

What we can do with the token:
- Create clips on your channel (that's it!)

What we store (locally on YOUR computer only):
- Your Twitch username (for display)
- The access token (for creating clips)

What we DO NOT store or access:
[X] Your password
[X] Your email
[X] Your personal information
[X] Your stream key
[X] Your payment info

All data stays on your computer. Nothing is sent to any server except Twitch's API when creating clips.

You can revoke access anytime at:
twitch.tv/settings/connections
"@
    
    $result = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
        $privacyText + "`n`nDo you want to continue connecting to Twitch?",
        "Privacy Notice",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
    
    return ($result -eq 'Yes')
}

function Start-TwitchOAuth {
    <#
    .SYNOPSIS
        Initiates Twitch OAuth flow for clip permissions
    .DESCRIPTION
        Opens browser for user authorization and captures the token via localhost redirect
    #>
    
    # ============================================
    # EVENT ORGANIZER: Set your Client ID here!
    # ============================================
    $ClientId = $script:Config.TwitchClientId
    
    if ([string]::IsNullOrWhiteSpace($ClientId) -or $ClientId -eq "YOUR_CLIENT_ID_HERE") {
        [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "Twitch Client ID not configured.`n`nEvent organizers need to set up a Twitch App and enter the Client ID in the script configuration.",
            "Setup Required",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        return $null
    }
    
    $RedirectUri = "http://localhost:3000/callback"
    $Scopes = "clips:edit"
    
    # Build auth URL (Implicit Grant Flow)
    $authUrl = "https://id.twitch.tv/oauth2/authorize" +
               "?client_id=$ClientId" +
               "&redirect_uri=$([System.Uri]::EscapeDataString($RedirectUri))" +
               "&response_type=token" +
               "&scope=$([System.Uri]::EscapeDataString($Scopes))"
    
    try {
        # Start HTTP listener
        $listener = New-Object System.Net.HttpListener
        $listener.Prefixes.Add("http://localhost:3000/")
        $listener.Start()
        
        Write-Log "Starting Twitch authorization..." -ForegroundColor Cyan
        
        # Open browser
        Start-Process $authUrl
        
        # Show waiting dialog
        $waitForm = New-Object System.Windows.Forms.Form
        $waitForm.Text = "Waiting for Authorization..."
        $waitForm.Size = New-Object System.Drawing.Size(400, 150)
        $waitForm.StartPosition = 'CenterScreen'
        $waitForm.FormBorderStyle = 'FixedDialog'
        $waitForm.MaximizeBox = $false
        $waitForm.MinimizeBox = $false
        $waitForm.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
        
        $lblWait = New-Object System.Windows.Forms.Label
        $lblWait.Text = "Please authorize in your browser...`n`nThis window will close automatically."
        $lblWait.ForeColor = [System.Drawing.Color]::White
        $lblWait.AutoSize = $false
        $lblWait.Size = New-Object System.Drawing.Size(360, 60)
        $lblWait.Location = New-Object System.Drawing.Point(20, 20)
        $lblWait.TextAlign = 'MiddleCenter'
        
        $btnCancel = New-Object System.Windows.Forms.Button
        $btnCancel.Text = "Cancel"
        $btnCancel.Location = New-Object System.Drawing.Point(150, 80)
        $btnCancel.Size = New-Object System.Drawing.Size(100, 30)
        $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        
        $waitForm.Controls.AddRange(@($lblWait, $btnCancel))
        
        # Handle async listening
        $context = $null
        $asyncResult = $listener.BeginGetContext($null, $null)
        
        # Timer to check for response
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 500
        $timer.Add_Tick({
            if ($asyncResult.IsCompleted) {
                $timer.Stop()
                $waitForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
                $waitForm.Close()
            }
        })
        $timer.Start()
        
        $result = $waitForm.ShowDialog()
        $timer.Stop()
        
        if ($result -eq [System.Windows.Forms.DialogResult]::Cancel) {
            $listener.Stop()
            return $null
        }
        
        # Get the context
        $context = $listener.EndGetContext($asyncResult)
        $request = $context.Request
        
        # Send response page that extracts the token from URL fragment
        $responseHtml = @"
<!DOCTYPE html>
<html>
<head>
    <title>The Hunt - Authorization</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #2d1f3d 100%);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            padding: 40px;
            background: rgba(0,0,0,0.3);
            border-radius: 15px;
            border: 2px solid #FFB74D;
        }
        h1 { color: #FFB74D; }
        .success { color: #4CAF50; font-size: 48px; }
        p { color: #ccc; }
    </style>
</head>
<body>
    <div class="container">
        <div class="success">[OK]</div>
        <h1>Authorization Successful!</h1>
        <p>You can close this window and return to the Hunt Tracker.</p>
        <p id="status">Processing...</p>
    </div>
    <script>
        // Extract token from URL fragment
        const hash = window.location.hash.substring(1);
        const params = new URLSearchParams(hash);
        const token = params.get('access_token');
        
        if (token) {
            // Send token to our callback endpoint
            fetch('/token?access_token=' + token)
                .then(() => {
                    document.getElementById('status').textContent = 'Connected! You may close this window.';
                })
                .catch(() => {
                    document.getElementById('status').textContent = 'Token received. Close this window.';
                });
        }
    </script>
</body>
</html>
"@
        
        $buffer = [System.Text.Encoding]::UTF8.GetBytes($responseHtml)
        $context.Response.ContentLength64 = $buffer.Length
        $context.Response.ContentType = "text/html"
        $context.Response.OutputStream.Write($buffer, 0, $buffer.Length)
        $context.Response.OutputStream.Close()
        
        # Wait for the token callback (non-blocking to keep UI responsive)
        $tokenResult = $listener.BeginGetContext($null, $null)
        $timeout = 0
        while (-not $tokenResult.IsCompleted -and $timeout -lt 30) {
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 100
            $timeout += 0.1
        }
        
        $accessToken = $null
        
        if ($tokenResult.IsCompleted) {
            $tokenContext = $listener.EndGetContext($tokenResult)
            $tokenRequest = $tokenContext.Request
            
            # Extract token from query string
            $queryString = $tokenRequest.Url.Query
            if ($queryString -match "access_token=([^&]+)") {
                $accessToken = $Matches[1]
            }
            
            # Send simple response
            $tokenContext.Response.StatusCode = 200
            $tokenContext.Response.Close()
        }
        
        $listener.Stop()
        
        if ($accessToken) {
            # Get user info to confirm and get channel name
            $headers = @{
                "Authorization" = "Bearer $accessToken"
                "Client-Id" = $ClientId
            }
            
            try {
                $userInfo = Invoke-RestMethod -Uri "https://api.twitch.tv/helix/users" -Headers $headers -Method Get
                $channelName = $userInfo.data[0].login
                $displayName = $userInfo.data[0].display_name
                
                # Save to config
                $script:Config.TwitchAccessToken = $accessToken
                $script:Config.TwitchChannelName = $channelName
                Save-Settings

                # Bring tracker to front after browser auth
                $script:MainForm.TopMost = $true
                $script:MainForm.Activate()
                $script:MainForm.TopMost = $false

                [System.Windows.Forms.MessageBox]::Show($script:MainForm,
                    "Successfully connected to Twitch!`n`nChannel: $displayName",
                    "Connected",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                )
                
                return @{
                    Success = $true
                    Token = $accessToken
                    ChannelName = $channelName
                    DisplayName = $displayName
                }
            }
            catch {
                return @{ Success = $false; Error = "Failed to get user info: $($_.Exception.Message)" }
            }
        }
        else {
            return @{ Success = $false; Error = "No token received" }
        }
    }
    catch {
        if ($listener) { $listener.Stop() }
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

function Test-TwitchConnection {
    if ([string]::IsNullOrWhiteSpace($script:Config.TwitchAccessToken)) {
        return @{ Connected = $false; Message = "Not connected" }
    }
    
    try {
        $headers = @{
            "Authorization" = "Bearer $($script:Config.TwitchAccessToken)"
            "Client-Id" = $script:Config.TwitchClientId
        }
        
        $userInfo = Invoke-RestMethod -Uri "https://api.twitch.tv/helix/users" -Headers $headers -Method Get
        $channelName = $userInfo.data[0].display_name
        
        return @{ Connected = $true; ChannelName = $channelName }
    }
    catch {
        return @{ Connected = $false; Message = "Token expired or invalid" }
    }
}
#endregion

#region Clip Functions
function New-TwitchClip {
    param([string]$Title = "Hunt Drop!")
    
    if ([string]::IsNullOrWhiteSpace($script:Config.TwitchAccessToken) -or 
        [string]::IsNullOrWhiteSpace($script:Config.TwitchClientId)) {
        return @{ Success = $false; Error = "Twitch not connected. Click 'Connect Twitch' in Settings." }
    }
    
    try {
        # Get broadcaster ID
        $headers = @{
            "Authorization" = "Bearer $($script:Config.TwitchAccessToken)"
            "Client-Id" = $script:Config.TwitchClientId
        }
        
        # Get user's own broadcaster ID (from the authorized user)
        $userResponse = Invoke-RestMethod -Uri "https://api.twitch.tv/helix/users" -Headers $headers -Method Get
        $broadcasterId = $userResponse.data[0].id
        $channelName = $userResponse.data[0].display_name
        
        # Create clip
        $clipResponse = Invoke-RestMethod -Uri "https://api.twitch.tv/helix/clips?broadcaster_id=$broadcasterId" -Headers $headers -Method Post
        
        if ($clipResponse.data) {
            $clipId = $clipResponse.data[0].id
            $editUrl = $clipResponse.data[0].edit_url
            
            # Wait for clip to process
            Start-Sleep -Seconds 3
            
            # Get final clip URL
            $clipData = Invoke-RestMethod -Uri "https://api.twitch.tv/helix/clips?id=$clipId" -Headers $headers -Method Get
            $clipUrl = "https://clips.twitch.tv/$clipId"
            
            return @{
                Success = $true
                ClipId = $clipId
                ClipUrl = $clipUrl
                EditUrl = $editUrl
                Channel = $channelName
            }
        }
        
        return @{ Success = $false; Error = "No clip data returned - make sure you're currently streaming!" }
    }
    catch {
        $errorMsg = $_.Exception.Message
        if ($errorMsg -match "401") {
            return @{ Success = $false; Error = "Authorization expired. Please reconnect Twitch in Settings." }
        }
        elseif ($errorMsg -match "404") {
            return @{ Success = $false; Error = "Cannot create clip - are you currently live streaming?" }
        }
        return @{ Success = $false; Error = $errorMsg }
    }
}

function New-KickClip {
    param([string]$Title = "Hunt Drop!")
    
    # Kick's API is more limited - we'll use their clip endpoint if available
    # For now, return a placeholder for manual clip creation
    if ([string]::IsNullOrWhiteSpace($script:Config.KickChannelName)) {
        return @{ Success = $false; Error = "Kick channel not configured" }
    }
    
    # Kick doesn't have a public clip API like Twitch
    # We'll open the channel page for manual clipping
    $kickUrl = "https://kick.com/$($script:Config.KickChannelName)"
    
    return @{
        Success = $true
        ClipUrl = $kickUrl
        Manual = $true
        Message = "Kick requires manual clipping. Channel opened."
    }
}

function Request-Clip {
    param(
        [string]$Platform = "Twitch",
        [string]$ItemName = ""
    )
    
    $title = if ($ItemName) { "Hunt Drop: $ItemName" } else { "Hunt Drop!" }
    
    $result = switch ($Platform) {
        "Twitch" { New-TwitchClip -Title $title }
        "Kick" { New-KickClip -Title $title }
        default { @{ Success = $false; Error = "Unknown platform" } }
    }
    
    if ($result.Success) {
        $script:Session.ClipLinks += @{
            Platform = $Platform
            Url = $result.ClipUrl
            Item = $ItemName
            Timestamp = (Get-Date).ToString("o")
        }
        $script:sessionDataDirty = $true; Save-SessionData
        
        # Copy clip title to clipboard for easy renaming
        $clipTitle = if ($ItemName) { "Hunt Drop: $ItemName" } else { "Hunt Drop!" }
        [System.Windows.Forms.Clipboard]::SetText($clipTitle)
        
        # Open clip editor in browser so user can rename the clip
        if ($result.EditUrl) {
            Start-Process $result.EditUrl
        }
    }
    
    return $result
}
#endregion

#region Drop Recording Functions
function Show-SourceSelector {
    param(
        [string]$ItemName,
        [string]$DefaultSource
    )
    
    $theme = Get-CurrentTheme
    
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "Select Drop Source"
    $dialog.Size = New-Object System.Drawing.Size(350, 180)
    $dialog.StartPosition = 'CenterParent'
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.BackColor = $theme.Background
    
    $lblItem = New-Object System.Windows.Forms.Label
    $lblItem.Text = "Recording: $ItemName"
    $lblItem.Location = New-Object System.Drawing.Point(20, 15)
    $lblItem.Size = New-Object System.Drawing.Size(300, 25)
    $lblItem.ForeColor = $theme.Primary
    $lblItem.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    
    $lblSource = New-Object System.Windows.Forms.Label
    $lblSource.Text = "Where did it drop from?"
    $lblSource.Location = New-Object System.Drawing.Point(20, 45)
    $lblSource.Size = New-Object System.Drawing.Size(300, 20)
    $lblSource.ForeColor = $theme.Text
    
    $cmbSource = New-Object System.Windows.Forms.ComboBox
    $cmbSource.Location = New-Object System.Drawing.Point(20, 70)
    $cmbSource.Size = New-Object System.Drawing.Size(295, 25)
    $cmbSource.DropDownStyle = 'DropDownList'
    $cmbSource.BackColor = $theme.Surface
    $cmbSource.ForeColor = $theme.Text
    
    # Add boss source (may have multiple separated by /)
    $sources = @()
    if ($DefaultSource -and $DefaultSource -ne "World Drop") {
        foreach ($src in ($DefaultSource -split '/')) {
            $sources += $src.Trim()
        }
    }
    $sources += "World Drop"
    
    foreach ($src in $sources) {
        [void]$cmbSource.Items.Add($src)
    }
    $cmbSource.SelectedIndex = 0
    
    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "Record"
    $btnOK.Location = New-Object System.Drawing.Point(120, 105)
    $btnOK.Size = New-Object System.Drawing.Size(100, 30)
    $btnOK.BackColor = $theme.Primary
    $btnOK.ForeColor = [System.Drawing.Color]::White
    $btnOK.FlatStyle = 'Flat'
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    
    $dialog.Controls.AddRange(@($lblItem, $lblSource, $cmbSource, $btnOK))
    $dialog.AcceptButton = $btnOK
    
    $result = $dialog.ShowDialog()
    
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        return $cmbSource.SelectedItem.ToString()
    }
    return $null
}

function Record-Drop {
    param(
        [Parameter(Mandatory)]
        [PSCustomObject]$Item,
        [string]$ClipUrl = ""
    )
    
    # Check for duplicate - same item already recorded
    $existing = $script:Session.Drops | Where-Object { $_.ItemName -eq $Item.ItemName }
    if ($existing) {
        [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "'$($Item.ItemName)' has already been recorded!`n`nEach item can only be claimed once.",
            "Duplicate Drop",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        return $null
    }
    
    $points = if ($Item.Points) { [double]$Item.Points } else { 1.0 }
    
    # Use SelectedSource if user picked one, otherwise fall back to Source/BossName
    $bossName = if ($Item.SelectedSource) { $Item.SelectedSource } 
                elseif ($Item.Source) { $Item.Source } 
                elseif ($Item.BossName) { $Item.BossName } 
                else { "World Drop" }
    
    $drop = @{
        ItemName = $Item.ItemName
        BossName = $bossName
        GameMode = if ($Item.GameMode) { $Item.GameMode } else { "N/A" }
        Type = $Item.Type
        Manufacturer = $Item.Manufacturer
        Points = $points
        ClipUrl = $ClipUrl
        Timestamp = (Get-Date).ToString("o")
        Submitted = $false
    }
    
    $script:Session.Drops += $drop
    $script:Session.TotalScore += $points
    
    $script:sessionDataDirty = $true; Save-SessionData
    
    return $drop
}

function Get-FilteredItems {
    param(
        [string]$SearchText = "",
        [string]$Category = "All",
        [string]$GameMode = "All",
        [string]$Boss = "All",
        [bool]$IncludeWorldDrops = $false  # World drops have no points, exclude by default
    )
    
    $allItems = @()
    
    # Add boss drops
    foreach ($item in $script:BossDrops) {
        $allItems += [PSCustomObject]@{
            ItemName = $item.ItemName
            Source = $item.BossName
            Type = $item.Type
            Manufacturer = $item.Manufacturer
            GameMode = $item.GameMode
            Points = $item.Points
            HasShiny = $item.HasShiny
            Mission = $item.Mission
            Notes = $item.Notes
            IsBossDrop = $true
        }
    }
    
    # Only add world drops if requested (they have no point values in the hunt)
    if ($IncludeWorldDrops) {
        foreach ($item in $script:WorldDrops) {
            $allItems += [PSCustomObject]@{
                ItemName = $item.ItemName
                Source = "World Drop"
                Type = $item.Type
                Manufacturer = $item.Manufacturer
                GameMode = "Any"
                Points = 0  # No points for world drops
                HasShiny = $item.HasShiny
                Mission = ""
                Notes = $item.Notes
                IsBossDrop = $false
            }
        }
    }
    
    # Apply filters
    $filtered = $allItems
    
    if (-not [string]::IsNullOrWhiteSpace($SearchText)) {
        $filtered = $filtered | Where-Object {
            $_.ItemName -like "*$SearchText*" -or
            $_.Source -like "*$SearchText*" -or
            $_.Manufacturer -like "*$SearchText*"
        }
    }
    
    if ($Category -ne "All") {
        $filtered = $filtered | Where-Object { $_.Type -eq $Category }
    }
    
    if ($GameMode -ne "All") {
        $filtered = $filtered | Where-Object { $_.GameMode -eq $GameMode -or $_.GameMode -eq "Any" }
    }
    
    if ($Boss -ne "All") {
        $filtered = $filtered | Where-Object { $_.Source -eq $Boss }
    }
    
    return $filtered | Sort-Object ItemName
}
#endregion

#region Export Functions
function Export-SessionToJson {
    param([string]$FilePath)
    
    $export = @{
        Event = "The Hunt 2026"
        Game = $script:Config.SelectedGame
        Player = $script:Session.PlayerName
        SubmittedAt = (Get-Date).ToString("o")
        SessionStart = if ($script:Session.StartTime) { $script:Session.StartTime.ToString("o") } else { $null }
        TotalScore = $script:Session.TotalScore
        TotalDrops = $script:Session.Drops.Count
        Drops = $script:Session.Drops
        Clips = $script:Session.ClipLinks
    }
    
    $export | ConvertTo-Json -Depth 10 | Set-Content $FilePath -Encoding UTF8
    return $FilePath
}

function Export-SessionToCsv {
    param([string]$FilePath)
    
    $script:Session.Drops | Select-Object @(
        'ItemName',
        'BossName',
        'GameMode',
        'Type',
        'Points',
        'ClipUrl',
        'Timestamp'
    ) | Export-Csv -Path $FilePath -NoTypeInformation
    
    return $FilePath
}

function Submit-ToWebsite {
    # Browser-assist submission - opens per-game item list page
    $claimUrls = @{
        BL2 = "https://2026.bl4hunt.com/bl2-item-list/"
        BL3 = "https://2026.bl4hunt.com/bl3-item-list/"
        BL4 = "https://2026.bl4hunt.com/bl4-item-list/"
    }
    $huntUrl = $claimUrls[$script:Config.SelectedGame]
    if (-not $huntUrl) { $huntUrl = $claimUrls["BL4"] }
    
    # Get unsubmitted drops with clips
    $unsubmitted = @($script:Session.Drops | Where-Object { 
        (-not $_.Submitted) -and $_.ClipUrl -and $_.ClipUrl -ne "" 
    })
    
    if ($unsubmitted.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "No drops to submit!`n`nAll drops have either been submitted or are missing clips.",
            "Nothing to Submit",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        return
    }
    
    # Confirm start
    $confirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
        "Ready to submit $($unsubmitted.Count) drops ($($script:Config.SelectedGame))`n`nFor each drop, the tracker will:`n  1. Copy the clip URL to your clipboard`n  2. Open the item list page`n  3. Find the item, paste clip URL, click Claim`n`nMake sure you are LOGGED IN to bl4hunt.com first!`n`nStart submitting?",
        "Submit Drops to Hunt Website",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    
    if ($confirm -ne 'Yes') { return }
    
    # Open item list page once
    Start-Process $huntUrl
    Start-Sleep -Milliseconds 1500
    
    $submitted = 0
    $total = $unsubmitted.Count
    
    for ($i = 0; $i -lt $total; $i++) {
        $drop = $unsubmitted[$i]
        $dropNum = $i + 1
        
        # Copy clip URL to clipboard
        [System.Windows.Forms.Clipboard]::SetText($drop.ClipUrl)
        
        # Show instruction dialog
        $result = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "DROP $dropNum of ${total}:`n`n" +
            "Item: $($drop.ItemName)`n" +
            "Boss: $($drop.BossName)`n" +
            "Points: $($drop.Points)`n" +
            "Type: $($drop.Type)`n`n" +
            "Clip URL copied to clipboard!`n`n" +
            "On the item list page:`n" +
            "  1. Find '$($drop.ItemName)'`n" +
            "  2. Click Claim`n" +
            "  3. Paste clip URL (Ctrl+V)`n" +
            "  4. Submit`n`n" +
            "Click YES after you've claimed this drop.`n" +
            "Click NO to skip this drop.`n" +
            "Click CANCEL to stop submitting.",
            "Submit Drop $dropNum / $total - $($drop.ItemName)",
            [System.Windows.Forms.MessageBoxButtons]::YesNoCancel,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        
        if ($result -eq 'Yes') {
            # Mark as submitted - find in Session.Drops by timestamp
            for ($j = 0; $j -lt $script:Session.Drops.Count; $j++) {
                if ($script:Session.Drops[$j].Timestamp -eq $drop.Timestamp -and 
                    $script:Session.Drops[$j].ItemName -eq $drop.ItemName) {
                    $script:Session.Drops[$j].Submitted = $true
                    break
                }
            }
            $submitted++
            $script:sessionDataDirty = $true; Save-SessionData
        }
        elseif ($result -eq 'Cancel') {
            break
        }
        # 'No' = skip, continue to next
        
        # Re-copy next clip URL if continuing
    }
    
    [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
        "Submission complete!`n`n" +
        "Submitted: $submitted of $total drops`n" +
        "Remaining: $($total - $submitted) drops",
        "Submit Complete",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
}
#endregion

#region First Launch Setup
function Show-FirstLaunchSetup {
    <#
    .SYNOPSIS
        Shows welcome dialog on first launch to set up player name and Twitch
    #>
    
    $theme = Get-CurrentTheme
    
    $setupForm = New-Object System.Windows.Forms.Form
    $setupForm.Text = "Welcome to The Hunt!"
    $setupForm.Size = New-Object System.Drawing.Size(500, 420)
    $setupForm.StartPosition = 'CenterScreen'
    $setupForm.FormBorderStyle = 'FixedDialog'
    $setupForm.MaximizeBox = $false
    $setupForm.MinimizeBox = $false
    $setupForm.BackColor = $theme.Background
    
    # Header
    $lblWelcome = New-Object System.Windows.Forms.Label
    $lblWelcome.Text = "THE HUNT 2026"
    $lblWelcome.Font = Get-HuntFont -Size 18
    $lblWelcome.ForeColor = $theme.Primary
    $lblWelcome.Location = New-Object System.Drawing.Point(20, 20)
    $lblWelcome.AutoSize = $true
    
    $lblSubtitle = New-Object System.Windows.Forms.Label
    $lblSubtitle.Text = "Let's get you set up for the event!"
    $lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $lblSubtitle.ForeColor = $theme.TextMuted
    $lblSubtitle.Location = New-Object System.Drawing.Point(20, 55)
    $lblSubtitle.AutoSize = $true
    
    # Player Name Section
    $grpPlayer = New-Object System.Windows.Forms.GroupBox
    $grpPlayer.Text = "Step 1: Your Info"
    $grpPlayer.Location = New-Object System.Drawing.Point(20, 90)
    $grpPlayer.Size = New-Object System.Drawing.Size(445, 70)
    $grpPlayer.ForeColor = $theme.Text
    
    $lblName = New-Object System.Windows.Forms.Label
    $lblName.Text = "Player/Channel Name:"
    $lblName.Location = New-Object System.Drawing.Point(15, 28)
    $lblName.AutoSize = $true
    
    $txtName = New-Object System.Windows.Forms.TextBox
    $txtName.Location = New-Object System.Drawing.Point(160, 25)
    $txtName.Size = New-Object System.Drawing.Size(265, 25)
    $txtName.BackColor = $theme.Surface
    $txtName.ForeColor = $theme.Text
    $txtName.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    
    $grpPlayer.Controls.AddRange(@($lblName, $txtName))
    
    # Twitch Section
    $grpTwitch = New-Object System.Windows.Forms.GroupBox
    $grpTwitch.Text = "Step 2: Connect Twitch (Optional)"
    $grpTwitch.Location = New-Object System.Drawing.Point(20, 170)
    $grpTwitch.Size = New-Object System.Drawing.Size(445, 130)
    $grpTwitch.ForeColor = $theme.Text
    
    $lblTwitchInfo = New-Object System.Windows.Forms.Label
    $lblTwitchInfo.Text = "Connect your Twitch to create clips when you get drops.`nYou can always do this later in Settings."
    $lblTwitchInfo.Location = New-Object System.Drawing.Point(15, 25)
    $lblTwitchInfo.Size = New-Object System.Drawing.Size(410, 35)
    $lblTwitchInfo.ForeColor = $theme.TextMuted
    
    $lblTwitchStatus = New-Object System.Windows.Forms.Label
    $lblTwitchStatus.Text = "Not connected"
    $lblTwitchStatus.Location = New-Object System.Drawing.Point(15, 70)
    $lblTwitchStatus.Size = New-Object System.Drawing.Size(250, 20)
    $lblTwitchStatus.ForeColor = $theme.TextMuted
    
    $btnConnectTwitch = New-Object System.Windows.Forms.Button
    $btnConnectTwitch.Text = "Connect Twitch"
    $btnConnectTwitch.Location = New-Object System.Drawing.Point(15, 90)
    $btnConnectTwitch.Size = New-Object System.Drawing.Size(180, 35)
    $btnConnectTwitch.BackColor = [System.Drawing.Color]::FromArgb(145, 70, 255)
    $btnConnectTwitch.ForeColor = [System.Drawing.Color]::White
    $btnConnectTwitch.FlatStyle = 'Flat'
    $btnConnectTwitch.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $btnConnectTwitch.Add_Click({
        # Show privacy notice first
        if (Show-TwitchPrivacyNotice) {
            $result = Start-TwitchOAuth
            if ($result -and $result.Success) {
                $lblTwitchStatus.Text = "Connected as: $($result.DisplayName)"
                $lblTwitchStatus.ForeColor = [System.Drawing.Color]::FromArgb(76, 175, 80)
                $txtName.Text = $result.DisplayName
            }
        }
    })
    
    $grpTwitch.Controls.AddRange(@($lblTwitchInfo, $lblTwitchStatus, $btnConnectTwitch))
    
    # Buttons
    $btnStart = New-Object System.Windows.Forms.Button
    $btnStart.Text = "Start Tracking!"
    $btnStart.Location = New-Object System.Drawing.Point(20, 320)
    $btnStart.Size = New-Object System.Drawing.Size(215, 45)
    $btnStart.BackColor = $theme.Success
    $btnStart.ForeColor = [System.Drawing.Color]::White
    $btnStart.FlatStyle = 'Flat'
    $btnStart.Font = Get-HuntFont -Size 14
    $btnStart.Add_Click({
        if ([string]::IsNullOrWhiteSpace($txtName.Text)) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "Please enter your player/channel name!",
                "Name Required",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            return
        }
        
        $script:Session.PlayerName = $txtName.Text
        $script:FirstLaunchComplete = $true
        $script:sessionDataDirty = $true; Save-SessionData
        Save-Settings
        
        $setupForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $setupForm.Close()
    })
    
    $btnSkip = New-Object System.Windows.Forms.Button
    $btnSkip.Text = "Skip for Now"
    $btnSkip.Location = New-Object System.Drawing.Point(250, 320)
    $btnSkip.Size = New-Object System.Drawing.Size(215, 45)
    $btnSkip.BackColor = $theme.Surface
    $btnSkip.ForeColor = $theme.Text
    $btnSkip.FlatStyle = 'Flat'
    $btnSkip.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $btnSkip.Add_Click({
        $script:FirstLaunchComplete = $true
        Save-Settings
        
        $setupForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $setupForm.Close()
    })
    
    # Footer
    $lblFooter = New-Object System.Windows.Forms.Label
    $lblFooter.Text = "You can change these settings anytime by clicking Settings"
    $lblFooter.Location = New-Object System.Drawing.Point(20, 375)
    $lblFooter.AutoSize = $true
    $lblFooter.ForeColor = $theme.TextMuted
    $lblFooter.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    
    $setupForm.Controls.AddRange(@($lblWelcome, $lblSubtitle, $grpPlayer, $grpTwitch, $btnStart, $btnSkip, $lblFooter))
    
    return $setupForm.ShowDialog()
}

function Test-FirstLaunch {
    # Check if setup has been completed before
    if ($script:FirstLaunchComplete -eq $true) {
        return $false
    }
    
    # Check if this is first launch (no settings file)
    if (-not (Test-Path $script:Config.SettingsFile)) {
        return $true
    }
    
    # Check if Twitch was never connected
    if ([string]::IsNullOrWhiteSpace($script:Config.TwitchChannelName)) {
        return $true
    }
    
    return $false
}
#endregion

#region GUI Functions
function Get-CurrentTheme {
    if ($script:Config.DarkMode) {
        return $script:Theme.Dark
    }
    return $script:Theme.Light
}

function Apply-Theme {
    param([System.Windows.Forms.Control]$Control)
    
    $theme = Get-CurrentTheme
    
    try {
        $Control.BackColor = $theme.Background
        $Control.ForeColor = $theme.Text
    } catch { }
    
    foreach ($child in $Control.Controls) {
        try {
            if ($child -is [System.Windows.Forms.GroupBox]) {
                $child.ForeColor = $theme.Text
                Apply-Theme -Control $child
            }
            elseif ($child -is [System.Windows.Forms.Button]) {
                $child.BackColor = $theme.Surface
                $child.ForeColor = $theme.Text
                $child.FlatStyle = 'Flat'
                $child.FlatAppearance.BorderColor = $theme.Border
            }
            elseif ($child -is [System.Windows.Forms.TextBox]) {
                $child.BackColor = $theme.Surface
                $child.ForeColor = $theme.Text
            }
            elseif ($child -is [System.Windows.Forms.ComboBox]) {
                $child.BackColor = $theme.Surface
                $child.ForeColor = $theme.Text
            }
            elseif ($child -is [System.Windows.Forms.ListBox] -or $child -is [System.Windows.Forms.ListView]) {
                $child.BackColor = $theme.Surface
                $child.ForeColor = $theme.Text
            }
            elseif ($child -is [System.Windows.Forms.DataGridView]) {
                $child.BackgroundColor = $theme.Surface
                $child.ForeColor = $theme.Text
                $child.GridColor = $theme.Border
                $child.DefaultCellStyle.BackColor = $theme.Surface
                $child.DefaultCellStyle.ForeColor = $theme.Text
                $child.ColumnHeadersDefaultCellStyle.BackColor = $theme.Background
                $child.ColumnHeadersDefaultCellStyle.ForeColor = $theme.Text
                $child.EnableHeadersVisualStyles = $false
            }
            elseif ($child -is [System.Windows.Forms.Label]) {
                $child.ForeColor = $theme.Text
            }
            elseif ($child -is [System.Windows.Forms.CheckBox]) {
                $child.ForeColor = $theme.Text
            }
            elseif ($child -is [System.Windows.Forms.Panel]) {
                $child.BackColor = $theme.Surface
                Apply-Theme -Control $child
            }
            elseif ($child -is [System.Windows.Forms.TabControl]) {
                Apply-Theme -Control $child
            }
            elseif ($child -is [System.Windows.Forms.TabPage]) {
                $child.BackColor = $theme.Background
                Apply-Theme -Control $child
            }
        } catch { }
    }
}

function Update-ScoreDisplay {
    $totalItems = $script:BossDrops.Count
    $dropsCollected = $script:Session.Drops.Count
    $dropsLeft = $totalItems - $dropsCollected
    
    if ($script:lblScore) {
        $script:lblScore.Text = "SCORE: $($script:Session.TotalScore)"
    }
    if ($script:lblDropsLeft) {
        $script:lblDropsLeft.Text = "LEFT: $dropsLeft"
    }
    if ($script:lblCollected) {
        $script:lblCollected.Text = "GOT: $dropsCollected / $totalItems"
    }
}

function Update-DropsGrid {
    if ($script:dgvDrops) {
        $script:dgvDrops.Rows.Clear()
        
        foreach ($drop in ($script:Session.Drops | Sort-Object { [DateTime]::Parse($_.Timestamp) } -Descending)) {
            $dropTime = [DateTime]::Parse($drop.Timestamp)
            
            # Calculate time relative to session timer start
            if ($script:SessionTimerStart -and $dropTime -ge $script:SessionTimerStart) {
                # Drop made during current timer session
                $elapsed = $dropTime - $script:SessionTimerStart
                $totalElapsed = $script:SessionAccumulatedTime + $elapsed
                $time = "{0:00}:{1:00}:{2:00}" -f [Math]::Floor($totalElapsed.TotalHours), $totalElapsed.Minutes, $totalElapsed.Seconds
            } elseif ($script:AppStartTime -and $dropTime -ge $script:AppStartTime) {
                # Drop made this app session but before timer started
                $time = "Pre-Timer"
            } else {
                # Drop from previous app session
                $time = "Prev"
            }
            
            $clipStatus = if ($drop.ClipUrl -and $drop.ClipUrl -ne "") { 
                if ($drop.Submitted) { "[OK]" } else { "[C]" }
            } else { "" }
            
            [void]$script:dgvDrops.Rows.Add(
                $time,
                $drop.ItemName,
                $drop.BossName,
                "$($drop.Points) $clipStatus"
            )
        }
    }
}

function Update-ClipsList {
    if ($script:lstClips) {
        $script:lstClips.Items.Clear()
        foreach ($clip in $script:Session.ClipLinks) {
            $itemText = if ($clip.Item) { $clip.Item } else { "Manual Clip" }
            [void]$script:lstClips.Items.Add("[$($clip.Platform)] $itemText - $($clip.Url)")
        }
    }
}

function Update-ItemList {
    param(
        [string]$Search = "",
        [string]$Category = "All",
        [string]$GameMode = "All",
        [string]$Boss = "All"
    )
    
    if ($script:dgvItems) {
        $script:dgvItems.Rows.Clear()
        
        # Get list of collected item names
        $collectedItems = @($script:Session.Drops | ForEach-Object { $_.ItemName })
        
        $items = Get-FilteredItems -SearchText $Search -Category $Category -GameMode $GameMode -Boss $Boss
        $theme = Get-CurrentTheme
        
        foreach ($item in $items) {
            $rowIndex = $script:dgvItems.Rows.Add(
                $item.ItemName,
                $item.Source,
                $item.Mission,
                $item.Type,
                $item.Points
            )
            
            # Highlight collected items
            if ($collectedItems -contains $item.ItemName) {
                $script:dgvItems.Rows[$rowIndex].DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(50, 120, 50)  # Dark green
                $script:dgvItems.Rows[$rowIndex].DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(180, 255, 180)  # Light green text
            }
            else {
                # Item name column - bright gold
                $script:dgvItems.Rows[$rowIndex].Cells[0].Style.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
                $script:dgvItems.Rows[$rowIndex].Cells[0].Style.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
                
                # Highlight Pearl items (5 points) with cyan/pearl color
                if ($item.Points -ge 5) {
                    $pearlColor = [System.Drawing.Color]::FromArgb(180, 230, 255)  # Light cyan/pearl
                    $script:dgvItems.Rows[$rowIndex].DefaultCellStyle.ForeColor = $pearlColor
                    $script:dgvItems.Rows[$rowIndex].Cells[0].Style.ForeColor = $pearlColor
                    $script:dgvItems.Rows[$rowIndex].Cells[4].Style.ForeColor = $pearlColor
                    $script:dgvItems.Rows[$rowIndex].Cells[4].Style.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
                }
            }
        }
    }
}

function Show-QuickDropDialog {
    $theme = Get-CurrentTheme
    
    $quickForm = New-Object System.Windows.Forms.Form
    $quickForm.Text = "Quick Drop Log"
    $quickForm.Size = New-Object System.Drawing.Size(500, 400)
    $quickForm.StartPosition = 'CenterScreen'
    $quickForm.FormBorderStyle = 'FixedDialog'
    $quickForm.MaximizeBox = $false
    $quickForm.BackColor = $theme.Background
    $quickForm.ForeColor = $theme.Text
    $quickForm.TopMost = $true
    
    # Search box
    $lblSearch = New-Object System.Windows.Forms.Label
    $lblSearch.Text = "Search Item:"
    $lblSearch.Location = New-Object System.Drawing.Point(10, 15)
    $lblSearch.AutoSize = $true
    $lblSearch.ForeColor = $theme.Text
    
    $txtQuickSearch = New-Object System.Windows.Forms.TextBox
    $txtQuickSearch.Location = New-Object System.Drawing.Point(100, 12)
    $txtQuickSearch.Size = New-Object System.Drawing.Size(280, 25)
    $txtQuickSearch.BackColor = $theme.Surface
    $txtQuickSearch.ForeColor = $theme.Text
    
    # Item list
    $lstItems = New-Object System.Windows.Forms.ListBox
    $lstItems.Location = New-Object System.Drawing.Point(10, 50)
    $lstItems.Size = New-Object System.Drawing.Size(465, 220)
    $lstItems.BackColor = $theme.Surface
    $lstItems.ForeColor = $theme.Text
    
    # Auto-clip checkbox - default based on AutoClipOnDrop setting
    $chkClip = New-Object System.Windows.Forms.CheckBox
    $chkClip.Text = "Create Twitch Clip"
    $chkClip.Location = New-Object System.Drawing.Point(10, 280)
    $chkClip.AutoSize = $true
    $chkClip.ForeColor = $theme.Text
    $chkClip.Checked = $script:Config.AutoClipOnDrop
    
    # Buttons
    $btnRecord = New-Object System.Windows.Forms.Button
    $btnRecord.Text = "Record Drop"
    $btnRecord.Location = New-Object System.Drawing.Point(10, 320)
    $btnRecord.Size = New-Object System.Drawing.Size(150, 35)
    $btnRecord.BackColor = $theme.Success
    $btnRecord.ForeColor = [System.Drawing.Color]::White
    $btnRecord.FlatStyle = 'Flat'
    
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(325, 320)
    $btnCancel.Size = New-Object System.Drawing.Size(150, 35)
    $btnCancel.BackColor = $theme.Surface
    $btnCancel.ForeColor = $theme.Text
    $btnCancel.FlatStyle = 'Flat'
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    
    # Populate items
    $allItems = Get-FilteredItems
    foreach ($item in $allItems) {
        [void]$lstItems.Items.Add("$($item.ItemName) | $($item.Source) | $($item.Points) pts")
    }
    
    # Search filter
    $txtQuickSearch.Add_TextChanged({
        $lstItems.Items.Clear()
        $filtered = Get-FilteredItems -SearchText $txtQuickSearch.Text
        foreach ($item in $filtered) {
            [void]$lstItems.Items.Add("$($item.ItemName) | $($item.Source) | $($item.Points) pts")
        }
    })
    
    # Record button click
    $btnRecord.Add_Click({
        if ($lstItems.SelectedIndex -ge 0) {
            $selectedText = $lstItems.SelectedItem.ToString()
            $itemName = ($selectedText -split '\|')[0].Trim()
            
            $allItems = Get-FilteredItems
            $selectedItem = $allItems | Where-Object { $_.ItemName -eq $itemName } | Select-Object -First 1
            
            if ($selectedItem) {
                $clipUrl = ""
                if ($chkClip.Checked) {
                    $clipResult = Request-Clip -Platform "Twitch" -ItemName $selectedItem.ItemName
                    if ($clipResult.Success) {
                        $clipUrl = $clipResult.ClipUrl
                    }
                }
                
                $drop = Record-Drop -Item $selectedItem -ClipUrl $clipUrl
                
                Update-ScoreDisplay
                
                $quickForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
                $quickForm.Close()
            }
        }
        else {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Please select an item", "No Item Selected")
        }
    })
    
    $quickForm.Controls.AddRange(@($lblSearch, $txtQuickSearch, $lstItems, $chkClip, $btnRecord, $btnCancel))
    $quickForm.AcceptButton = $btnRecord
    $quickForm.CancelButton = $btnCancel
    
    $quickForm.ShowDialog()
}

function Show-SettingsDialog {
    $theme = Get-CurrentTheme
    
    $settingsForm = New-Object System.Windows.Forms.Form
    $settingsForm.Text = "Hunt Settings"
    $settingsForm.Size = New-Object System.Drawing.Size(500, 550)
    $settingsForm.StartPosition = 'CenterScreen'
    $settingsForm.FormBorderStyle = 'FixedDialog'
    $settingsForm.MaximizeBox = $false
    $settingsForm.BackColor = $theme.Background
    
    # Twitch Group
    $grpTwitch = New-Object System.Windows.Forms.GroupBox
    $grpTwitch.Text = "Twitch Connection"
    $grpTwitch.Location = New-Object System.Drawing.Point(10, 10)
    $grpTwitch.Size = New-Object System.Drawing.Size(465, 130)
    $grpTwitch.ForeColor = $theme.Text
    
    # Connection status
    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Location = New-Object System.Drawing.Point(10, 25)
    $lblStatus.Size = New-Object System.Drawing.Size(300, 20)
    $lblStatus.ForeColor = $theme.Text
    
    # Check current connection
    $connectionTest = Test-TwitchConnection
    if ($connectionTest.Connected) {
        $lblStatus.Text = "Connected as: $($connectionTest.ChannelName)"
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(76, 175, 80)
    } else {
        $lblStatus.Text = "Not connected"
        $lblStatus.ForeColor = $theme.TextMuted
    }
    
    # Connect button
    $btnConnect = New-Object System.Windows.Forms.Button
    $btnConnect.Text = "Connect Twitch"
    $btnConnect.Location = New-Object System.Drawing.Point(10, 50)
    $btnConnect.Size = New-Object System.Drawing.Size(200, 35)
    $btnConnect.BackColor = [System.Drawing.Color]::FromArgb(145, 70, 255)
    $btnConnect.ForeColor = [System.Drawing.Color]::White
    $btnConnect.FlatStyle = 'Flat'
    $btnConnect.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $btnConnect.Add_Click({
        # Show privacy notice first
        if (Show-TwitchPrivacyNotice) {
            $result = Start-TwitchOAuth
            if ($result.Success) {
                $lblStatus.Text = "Connected as: $($result.DisplayName)"
                $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(76, 175, 80)
            }
        }
    })
    
    # Disconnect button
    $btnDisconnect = New-Object System.Windows.Forms.Button
    $btnDisconnect.Text = "Disconnect"
    $btnDisconnect.Location = New-Object System.Drawing.Point(220, 50)
    $btnDisconnect.Size = New-Object System.Drawing.Size(100, 35)
    $btnDisconnect.BackColor = $theme.Surface
    $btnDisconnect.ForeColor = $theme.Text
    $btnDisconnect.FlatStyle = 'Flat'
    $btnDisconnect.Add_Click({
        $script:Config.TwitchAccessToken = ""
        $script:Config.TwitchChannelName = ""
        Save-Settings
        $lblStatus.Text = "Not connected"
        $lblStatus.ForeColor = $theme.TextMuted
    })
    
    # Help text
    $lblHelp = New-Object System.Windows.Forms.Label
    $lblHelp.Text = "Click 'Connect Twitch' to authorize clip creation on your channel."
    $lblHelp.Location = New-Object System.Drawing.Point(10, 95)
    $lblHelp.Size = New-Object System.Drawing.Size(440, 20)
    $lblHelp.ForeColor = $theme.TextMuted
    $lblHelp.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    
    $grpTwitch.Controls.AddRange(@($lblStatus, $btnConnect, $btnDisconnect, $lblHelp))
    
    # Kick Group
    $grpKick = New-Object System.Windows.Forms.GroupBox
    $grpKick.Text = "Kick Configuration (Manual Clips)"
    $grpKick.Location = New-Object System.Drawing.Point(10, 150)
    $grpKick.Size = New-Object System.Drawing.Size(465, 70)
    $grpKick.ForeColor = $theme.Text
    
    $lblKickChannel = New-Object System.Windows.Forms.Label
    $lblKickChannel.Text = "Channel Name:"
    $lblKickChannel.Location = New-Object System.Drawing.Point(10, 25)
    $lblKickChannel.AutoSize = $true
    
    $txtKickChannel = New-Object System.Windows.Forms.TextBox
    $txtKickChannel.Location = New-Object System.Drawing.Point(120, 22)
    $txtKickChannel.Size = New-Object System.Drawing.Size(330, 25)
    $txtKickChannel.Text = $script:Config.KickChannelName
    $txtKickChannel.BackColor = $theme.Surface
    $txtKickChannel.ForeColor = $theme.Text
    
    $grpKick.Controls.AddRange(@($lblKickChannel, $txtKickChannel))
    
    # Hotkeys Group
    $grpHotkeys = New-Object System.Windows.Forms.GroupBox
    $grpHotkeys.Text = "Hotkeys (Click box and press new key)"
    $grpHotkeys.Location = New-Object System.Drawing.Point(10, 230)
    $grpHotkeys.Size = New-Object System.Drawing.Size(465, 130)
    $grpHotkeys.ForeColor = $theme.Text
    
    $lblRecordKey = New-Object System.Windows.Forms.Label
    $lblRecordKey.Text = "Record Drop:"
    $lblRecordKey.Location = New-Object System.Drawing.Point(10, 25)
    $lblRecordKey.AutoSize = $true
    
    $txtRecordKey = New-Object System.Windows.Forms.TextBox
    $txtRecordKey.Location = New-Object System.Drawing.Point(120, 22)
    $txtRecordKey.Size = New-Object System.Drawing.Size(100, 25)
    $txtRecordKey.Text = $script:Config.RecordDropKey.ToString()
    $txtRecordKey.ReadOnly = $true
    $txtRecordKey.BackColor = $theme.Surface
    $txtRecordKey.ForeColor = $theme.Text
    $txtRecordKey.Add_KeyDown({ param($s, $e) $s.Text = $e.KeyCode.ToString(); $script:Config.RecordDropKey = $e.KeyCode; $e.Handled = $true })
    
    $lblClipKey = New-Object System.Windows.Forms.Label
    $lblClipKey.Text = "Create Clip:"
    $lblClipKey.Location = New-Object System.Drawing.Point(10, 55)
    $lblClipKey.AutoSize = $true
    
    $txtClipKey = New-Object System.Windows.Forms.TextBox
    $txtClipKey.Location = New-Object System.Drawing.Point(120, 52)
    $txtClipKey.Size = New-Object System.Drawing.Size(100, 25)
    $txtClipKey.Text = $script:Config.CreateClipKey.ToString()
    $txtClipKey.ReadOnly = $true
    $txtClipKey.BackColor = $theme.Surface
    $txtClipKey.ForeColor = $theme.Text
    $txtClipKey.Add_KeyDown({ param($s, $e) $s.Text = $e.KeyCode.ToString(); $script:Config.CreateClipKey = $e.KeyCode; $e.Handled = $true })
    
    $lblQuickKey = New-Object System.Windows.Forms.Label
    $lblQuickKey.Text = "Quick Log:"
    $lblQuickKey.Location = New-Object System.Drawing.Point(10, 85)
    $lblQuickKey.AutoSize = $true
    
    $txtQuickKey = New-Object System.Windows.Forms.TextBox
    $txtQuickKey.Location = New-Object System.Drawing.Point(120, 82)
    $txtQuickKey.Size = New-Object System.Drawing.Size(100, 25)
    $txtQuickKey.Text = $script:Config.QuickLogKey.ToString()
    $txtQuickKey.ReadOnly = $true
    $txtQuickKey.BackColor = $theme.Surface
    $txtQuickKey.ForeColor = $theme.Text
    $txtQuickKey.Add_KeyDown({ param($s, $e) $s.Text = $e.KeyCode.ToString(); $script:Config.QuickLogKey = $e.KeyCode; $e.Handled = $true })
    
    # Current hotkey hints
    $lblHotkeyHint = New-Object System.Windows.Forms.Label
    $lblHotkeyHint.Text = "Default: F5 (Record) | F6 (Clip) | F7 (Quick Log)"
    $lblHotkeyHint.Location = New-Object System.Drawing.Point(240, 55)
    $lblHotkeyHint.AutoSize = $true
    $lblHotkeyHint.ForeColor = $theme.TextMuted
    $lblHotkeyHint.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    
    $grpHotkeys.Controls.AddRange(@($lblRecordKey, $txtRecordKey, $lblClipKey, $txtClipKey, $lblQuickKey, $txtQuickKey, $lblHotkeyHint))
    
    # Options
    $chkDarkMode = New-Object System.Windows.Forms.CheckBox
    $chkDarkMode.Text = "Dark Mode"
    $chkDarkMode.Location = New-Object System.Drawing.Point(20, 375)
    $chkDarkMode.AutoSize = $true
    $chkDarkMode.Checked = $script:Config.DarkMode
    $chkDarkMode.ForeColor = $theme.Text
    
    $chkAutoClip = New-Object System.Windows.Forms.CheckBox
    $chkAutoClip.Text = "Auto-clip when recording drops"
    $chkAutoClip.Location = New-Object System.Drawing.Point(150, 375)
    $chkAutoClip.AutoSize = $true
    $chkAutoClip.Checked = $script:Config.AutoClipOnDrop
    $chkAutoClip.ForeColor = $theme.Text
    
    # UI Scale
    $lblUIScale = New-Object System.Windows.Forms.Label
    $lblUIScale.Text = "Text Size:"
    $lblUIScale.Location = New-Object System.Drawing.Point(350, 375)
    $lblUIScale.AutoSize = $true
    $lblUIScale.ForeColor = $theme.Text
    
    $cmbUIScale = New-Object System.Windows.Forms.ComboBox
    $cmbUIScale.Location = New-Object System.Drawing.Point(415, 372)
    $cmbUIScale.Size = New-Object System.Drawing.Size(60, 25)
    $cmbUIScale.DropDownStyle = 'DropDownList'
    $cmbUIScale.BackColor = $theme.Surface
    $cmbUIScale.ForeColor = $theme.Text
    [void]$cmbUIScale.Items.AddRange(@("100%", "125%", "150%"))
    switch ($script:Config.UIScale) {
        1.0 { $cmbUIScale.SelectedIndex = 0 }
        1.25 { $cmbUIScale.SelectedIndex = 1 }
        1.5 { $cmbUIScale.SelectedIndex = 2 }
        default { $cmbUIScale.SelectedIndex = 0 }
    }
    
    # Event info
    $lblEventInfo = New-Object System.Windows.Forms.Label
    $lblEventInfo.Text = "The Hunt 2026"
    $lblEventInfo.Location = New-Object System.Drawing.Point(20, 410)
    $lblEventInfo.AutoSize = $true
    $lblEventInfo.ForeColor = $theme.Primary
    $lblEventInfo.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    
    # Save button
    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = "Save Settings"
    $btnSave.Location = New-Object System.Drawing.Point(10, 460)
    $btnSave.Size = New-Object System.Drawing.Size(465, 40)
    $btnSave.BackColor = $theme.Success
    $btnSave.ForeColor = [System.Drawing.Color]::White
    $btnSave.FlatStyle = 'Flat'
    $btnSave.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $btnSave.Add_Click({
        $script:Config.KickChannelName = $txtKickChannel.Text
        $script:Config.DarkMode = $chkDarkMode.Checked
        $script:Config.AutoClipOnDrop = $chkAutoClip.Checked
        
        # Save UI Scale
        switch ($cmbUIScale.SelectedIndex) {
            0 { $script:Config.UIScale = 1.0 }
            1 { $script:Config.UIScale = 1.25 }
            2 { $script:Config.UIScale = 1.5 }
        }
        
        Save-Settings
        
        [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Settings saved! Restart the app for text size changes to take effect.", "Success")
        $settingsForm.Close()
    })
    
    $settingsForm.Controls.AddRange(@($grpTwitch, $grpKick, $grpHotkeys, $chkDarkMode, $chkAutoClip, $lblUIScale, $cmbUIScale, $lblEventInfo, $btnSave))
    $settingsForm.ShowDialog()
}


function Update-GameButtonStyles {
    $activeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)   # Gold
    $activeFG = [System.Drawing.Color]::FromArgb(66, 4, 21)       # Dark maroon
    $inactiveColor = [System.Drawing.Color]::FromArgb(80, 80, 80) # Gray
    $inactiveFG = [System.Drawing.Color]::FromArgb(200, 200, 200) # Light gray

    foreach ($btn in @($script:btnGameBL2, $script:btnGameBL3, $script:btnGameBL4)) {
        if ($null -eq $btn) { continue }
        if ($btn.Tag -eq $script:Config.SelectedGame) {
            $btn.BackColor = $activeColor
            $btn.ForeColor = $activeFG
        } else {
            $btn.BackColor = $inactiveColor
            $btn.ForeColor = $inactiveFG
        }
    }
}

function Set-ActiveGame {
    param([string]$Game)

    $script:Config.SelectedGame = $Game
    Save-Settings

    # Update button styles
    Update-GameButtonStyles

    # Reload data for new game
    $dataFile = Join-Path $script:AppDir $script:Config.GameDataFiles[$Game]
    if (Test-Path $dataFile) {
        $script:Config.DataFile = $dataFile
        Import-HuntData -FilePath $dataFile

        # Refresh UI
        if ($script:cmbBoss) {
            $script:cmbBoss.Items.Clear()
            [void]$script:cmbBoss.Items.Add("All")
            $uniqueBosses = $script:BossDrops | Select-Object -ExpandProperty BossName -Unique | Sort-Object
            foreach ($boss in $uniqueBosses) {
                [void]$script:cmbBoss.Items.Add($boss)
            }
            $script:cmbBoss.SelectedIndex = 0
        }

        # Update category filter based on game types
        if ($script:cmbCategory) {
            $script:cmbCategory.Items.Clear()
            [void]$script:cmbCategory.Items.Add("All")
            $uniqueTypes = $script:BossDrops | Select-Object -ExpandProperty Type -Unique | Sort-Object
            foreach ($t in $uniqueTypes) {
                if (-not [string]::IsNullOrWhiteSpace($t)) {
                    [void]$script:cmbCategory.Items.Add($t)
                }
            }
            $script:cmbCategory.SelectedIndex = 0
        }

        # Update game mode filter based on game
        if ($script:cmbGameMode) {
            $script:cmbGameMode.Items.Clear()
            [void]$script:cmbGameMode.Items.Add("All")
            $uniqueModes = $script:BossDrops | Select-Object -ExpandProperty GameMode -Unique | Sort-Object
            foreach ($mode in $uniqueModes) {
                if (-not [string]::IsNullOrWhiteSpace($mode)) {
                    [void]$script:cmbGameMode.Items.Add($mode)
                }
            }
            $script:cmbGameMode.SelectedIndex = 0
        }

        Update-ItemList -Search "" -Category "All" -GameMode "All" -Boss "All"
        Update-ScoreDisplay

        Write-Log "Switched to $($script:Config.GameLabels[$Game]) - $($script:BossDrops.Count) items loaded" -ForegroundColor Cyan
    } else {
        [System.Windows.Forms.MessageBox]::Show($script:MainForm,
            "Data file not found for $($script:Config.GameLabels[$Game]):`n$dataFile`n`nPlease place the file in the app folder.",
            "Data File Missing",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
    }
}

function Build-MainForm {
    try {
        $theme = Get-CurrentTheme
        
        # Main Form
        $form = New-Object System.Windows.Forms.Form
        $script:MainForm = $form
        $form.Text = "The Hunt - Charity Event Tracker"
        $form.Size = New-Object System.Drawing.Size(1000, 700)
        $form.MinimumSize = New-Object System.Drawing.Size(850, 550)
        $form.StartPosition = 'CenterScreen'
        $form.KeyPreview = $true
        
        # Set form icon (for title bar and taskbar)
        $icoPath = Join-Path $script:AppDir "hunt_logo.ico"
        if (Test-Path $icoPath) {
            try {
                $form.Icon = New-Object System.Drawing.Icon($icoPath)
            } catch { }
        }
    
    #region Header Panel
    $pnlHeader = New-Object System.Windows.Forms.Panel
    $pnlHeader.Dock = [System.Windows.Forms.DockStyle]::Top
    $pnlHeader.Height = 105
    $pnlHeader.BackColor = $theme.Surface
    
    # Logo
    $picLogo = New-Object System.Windows.Forms.PictureBox
    $picLogo.Location = New-Object System.Drawing.Point(10, 5)
    $picLogo.Size = New-Object System.Drawing.Size(80, 90)
    $picLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $logoPath = Join-Path $script:AppDir "hunt_logo.png"
    if (Test-Path $logoPath) {
        try {
            $picLogo.Image = [System.Drawing.Image]::FromFile($logoPath)
        } catch { }
    }
    
    # Row 1: Title + Session Timer + Buttons
    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text = "THE HUNT 2026"
    $lblTitle.Font = Get-HuntFont -Size 22
    $lblTitle.Location = New-Object System.Drawing.Point(95, 8)
    $lblTitle.AutoSize = $true
    $lblTitle.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    
    $script:lblSessionTimer = New-Object System.Windows.Forms.Label
    $script:lblSessionTimer.Text = "SESSION: 00:00:00"
    $script:lblSessionTimer.Font = Get-HuntFont -Size 16
    $script:lblSessionTimer.Location = New-Object System.Drawing.Point(350, 10)
    $script:lblSessionTimer.AutoSize = $true
    $script:lblSessionTimer.ForeColor = [System.Drawing.Color]::FromArgb(255, 248, 166)
    
    $script:btnSessionTimer = New-Object System.Windows.Forms.Button
    $script:btnSessionTimer.Text = "START"
    $script:btnSessionTimer.Size = New-Object System.Drawing.Size(70, 28)
    $script:btnSessionTimer.Location = New-Object System.Drawing.Point(550, 7)
    $script:btnSessionTimer.FlatStyle = 'Flat'
    $script:btnSessionTimer.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
    $script:btnSessionTimer.ForeColor = [System.Drawing.Color]::White
    $script:btnSessionTimer.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:btnSessionTimer.Add_Click({
        if ($script:SessionTimerRunning) {
            $script:SessionTimerRunning = $false
            $elapsed = (Get-Date) - $script:SessionTimerStart
            $script:SessionAccumulatedTime += $elapsed
            $script:btnSessionTimer.Text = "START"
            $script:btnSessionTimer.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
            $script:sessionDataDirty = $true; Save-SessionData
        } else {
            $script:SessionTimerRunning = $true
            $script:SessionTimerStart = Get-Date
            $script:btnSessionTimer.Text = "STOP"
            $script:btnSessionTimer.BackColor = [System.Drawing.Color]::FromArgb(198, 40, 40)
            $script:sessionDataDirty = $true; Save-SessionData
        }
    })
    
    $btnResetTimer = New-Object System.Windows.Forms.Button
    $btnResetTimer.Text = "Reset"
    $btnResetTimer.Size = New-Object System.Drawing.Size(50, 28)
    $btnResetTimer.Location = New-Object System.Drawing.Point(625, 7)
    $btnResetTimer.FlatStyle = 'Flat'
    $btnResetTimer.BackColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
    $btnResetTimer.ForeColor = [System.Drawing.Color]::White
    $btnResetTimer.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $btnResetTimer.Add_Click({
        $script:SessionTimerRunning = $false
        $script:SessionTimerStart = $null
        $script:SessionAccumulatedTime = [TimeSpan]::Zero
        $script:AppStartTime = Get-Date
        $script:lblSessionTimer.Text = "SESSION: 00:00:00"
        $script:btnSessionTimer.Text = "START"
        $script:btnSessionTimer.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
        Update-DropsGrid
        $script:sessionDataDirty = $true; Save-SessionData
    })
    
    $btnSettings = New-Object System.Windows.Forms.Button
    $btnSettings.Text = "..."
    $btnSettings.Size = New-Object System.Drawing.Size(30, 28)
    $btnSettings.Location = New-Object System.Drawing.Point(680, 7)
    $btnSettings.FlatStyle = 'Flat'
    $btnSettings.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    $btnSettings.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)
    $btnSettings.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
    $btnSettings.Add_Click({ Show-SettingsDialog; Apply-Theme -Control $form })

    # Game Selector Buttons
    $script:btnGameBL2 = New-Object System.Windows.Forms.Button
    $script:btnGameBL2.Text = "BL2"
    $script:btnGameBL2.Size = New-Object System.Drawing.Size(50, 28)
    $script:btnGameBL2.Location = New-Object System.Drawing.Point(95, 68)
    $script:btnGameBL2.FlatStyle = 'Flat'
    $script:btnGameBL2.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:btnGameBL2.Tag = "BL2"
    $script:btnGameBL2.Add_Click({ Set-ActiveGame "BL2" })

    $script:btnGameBL3 = New-Object System.Windows.Forms.Button
    $script:btnGameBL3.Text = "BL3"
    $script:btnGameBL3.Size = New-Object System.Drawing.Size(50, 28)
    $script:btnGameBL3.Location = New-Object System.Drawing.Point(150, 68)
    $script:btnGameBL3.FlatStyle = 'Flat'
    $script:btnGameBL3.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:btnGameBL3.Tag = "BL3"
    $script:btnGameBL3.Add_Click({ Set-ActiveGame "BL3" })

    $script:btnGameBL4 = New-Object System.Windows.Forms.Button
    $script:btnGameBL4.Text = "BL4"
    $script:btnGameBL4.Size = New-Object System.Drawing.Size(50, 28)
    $script:btnGameBL4.Location = New-Object System.Drawing.Point(205, 68)
    $script:btnGameBL4.FlatStyle = 'Flat'
    $script:btnGameBL4.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $script:btnGameBL4.Tag = "BL4"
    $script:btnGameBL4.Add_Click({ Set-ActiveGame "BL4" })

    $lblGameLabel = New-Object System.Windows.Forms.Label
    $lblGameLabel.Text = "GAME:"
    $lblGameLabel.Font = Get-HuntFont -Size 10
    $lblGameLabel.Location = New-Object System.Drawing.Point(265, 72)
    $lblGameLabel.AutoSize = $true
    $lblGameLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 248, 166)
    $lblGameLabel.Visible = $false  # Hidden - buttons are self-explanatory

    Update-GameButtonStyles

    # Row 2: Score + Left + Got - spread across right side
    $totalItems = $script:BossDrops.Count
    $dropsCollected = $script:Session.Drops.Count
    $dropsLeft = $totalItems - $dropsCollected
    
    $script:lblScore = New-Object System.Windows.Forms.Label
    $script:lblScore.Text = "SCORE: $($script:Session.TotalScore)"
    $script:lblScore.Font = Get-HuntFont -Size 18
    $script:lblScore.Location = New-Object System.Drawing.Point(350, 70)
    $script:lblScore.AutoSize = $true
    $script:lblScore.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    
    $script:lblDropsLeft = New-Object System.Windows.Forms.Label
    $script:lblDropsLeft.Text = "LEFT: $dropsLeft"
    $script:lblDropsLeft.Font = Get-HuntFont -Size 18
    $script:lblDropsLeft.Location = New-Object System.Drawing.Point(520, 70)
    $script:lblDropsLeft.AutoSize = $true
    $script:lblDropsLeft.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    
    $script:lblCollected = New-Object System.Windows.Forms.Label
    $script:lblCollected.Text = "GOT: $dropsCollected / $totalItems"
    $script:lblCollected.Font = Get-HuntFont -Size 18
    $script:lblCollected.Location = New-Object System.Drawing.Point(680, 70)
    $script:lblCollected.AutoSize = $true
    $script:lblCollected.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
    
    $pnlHeader.Controls.AddRange(@($picLogo, $lblTitle, $script:lblScore, $script:lblDropsLeft, $script:lblCollected, $script:lblSessionTimer, $script:btnSessionTimer, $btnResetTimer, $btnSettings, $script:btnGameBL2, $script:btnGameBL3, $script:btnGameBL4))
    #endregion
    
    #region Tab Control
    $tabControl = New-Object System.Windows.Forms.TabControl
    $tabControl.Dock = [System.Windows.Forms.DockStyle]::Fill
    $tabControl.Padding = New-Object System.Drawing.Point(10, 5)
    
    #region Tracking Tab
    $tabTracking = New-Object System.Windows.Forms.TabPage
    $tabTracking.Text = "Drop Tracking"
    $tabTracking.BackColor = $theme.Background
    $tabTracking.Padding = New-Object System.Windows.Forms.Padding(10)
    
    # Search/Filter Panel
    $script:pnlFilters = New-Object System.Windows.Forms.Panel
    $script:pnlFilters.Location = New-Object System.Drawing.Point(10, 10)
    $script:pnlFilters.Size = New-Object System.Drawing.Size(850, 50)
    $script:pnlFilters.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    
    $lblSearch = New-Object System.Windows.Forms.Label
    $lblSearch.Text = "Search:"
    $lblSearch.Location = New-Object System.Drawing.Point(5, 15)
    $lblSearch.AutoSize = $true
    $lblSearch.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    
    $script:txtSearch = New-Object System.Windows.Forms.TextBox
    $script:txtSearch.Location = New-Object System.Drawing.Point(60, 12)
    $script:txtSearch.Size = New-Object System.Drawing.Size(200, 25)
    $script:txtSearch.BackColor = $theme.Surface
    $script:txtSearch.ForeColor = $theme.Text
    
    $lblCategory = New-Object System.Windows.Forms.Label
    $lblCategory.Text = "Type:"
    $lblCategory.Location = New-Object System.Drawing.Point(280, 15)
    $lblCategory.AutoSize = $true
    $lblCategory.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    
    $script:cmbCategory = New-Object System.Windows.Forms.ComboBox
    $script:cmbCategory.Location = New-Object System.Drawing.Point(320, 12)
    $script:cmbCategory.Size = New-Object System.Drawing.Size(120, 25)
    $script:cmbCategory.DropDownStyle = 'DropDownList'
    [void]$script:cmbCategory.Items.Add("All")
    $uniqueTypes = $script:BossDrops | Select-Object -ExpandProperty Type -Unique | Sort-Object
    foreach ($typeVal in $uniqueTypes) {
        if (-not [string]::IsNullOrWhiteSpace($typeVal)) {
            [void]$script:cmbCategory.Items.Add($typeVal)
        }
    }
    $script:cmbCategory.SelectedIndex = 0
    $script:cmbCategory.BackColor = $theme.Surface
    $script:cmbCategory.ForeColor = $theme.Text
    
    $lblGameMode = New-Object System.Windows.Forms.Label
    $lblGameMode.Text = "Mode:"
    $lblGameMode.Location = New-Object System.Drawing.Point(460, 15)
    $lblGameMode.AutoSize = $true
    $lblGameMode.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    
    $script:cmbGameMode = New-Object System.Windows.Forms.ComboBox
    $script:cmbGameMode.Location = New-Object System.Drawing.Point(510, 12)
    $script:cmbGameMode.Size = New-Object System.Drawing.Size(100, 25)
    $script:cmbGameMode.DropDownStyle = 'DropDownList'
    [void]$script:cmbGameMode.Items.Add("All")
    $uniqueModes = $script:BossDrops | Select-Object -ExpandProperty GameMode -Unique | Sort-Object
    foreach ($modeVal in $uniqueModes) {
        if (-not [string]::IsNullOrWhiteSpace($modeVal)) {
            [void]$script:cmbGameMode.Items.Add($modeVal)
        }
    }
    $script:cmbGameMode.SelectedIndex = 0
    $script:cmbGameMode.BackColor = $theme.Surface
    $script:cmbGameMode.ForeColor = $theme.Text
    
    $lblBoss = New-Object System.Windows.Forms.Label
    $lblBoss.Text = "Boss:"
    $lblBoss.Location = New-Object System.Drawing.Point(620, 15)
    $lblBoss.AutoSize = $true
    $lblBoss.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    
    $script:cmbBoss = New-Object System.Windows.Forms.ComboBox
    $script:cmbBoss.Location = New-Object System.Drawing.Point(660, 12)
    $script:cmbBoss.Size = New-Object System.Drawing.Size(150, 25)
    $script:cmbBoss.DropDownStyle = 'DropDownList'
    $script:cmbBoss.BackColor = $theme.Surface
    $script:cmbBoss.ForeColor = $theme.Text
    [void]$script:cmbBoss.Items.Add("All")
    $script:cmbBoss.SelectedIndex = 0
    
    $script:pnlFilters.Controls.AddRange(@($lblSearch, $script:txtSearch, $lblCategory, $script:cmbCategory, $lblGameMode, $script:cmbGameMode, $lblBoss, $script:cmbBoss))
    
    # Items Grid (left side) - narrower to fit collected drops
    $script:dgvItems = New-Object System.Windows.Forms.DataGridView
    $script:dgvItems.Location = New-Object System.Drawing.Point(10, 65)
    $script:dgvItems.Size = New-Object System.Drawing.Size(500, 330)
    $script:dgvItems.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left
    $script:dgvItems.AllowUserToAddRows = $false
    $script:dgvItems.AllowUserToDeleteRows = $false
    $script:dgvItems.ReadOnly = $true
    $script:dgvItems.SelectionMode = 'FullRowSelect'
    $script:dgvItems.MultiSelect = $true
    $script:dgvItems.RowHeadersVisible = $false
    $script:dgvItems.AutoSizeColumnsMode = 'Fill'
    $script:dgvItems.BackgroundColor = $theme.Surface
    $script:dgvItems.DefaultCellStyle.BackColor = $theme.Surface
    $script:dgvItems.DefaultCellStyle.ForeColor = [System.Drawing.Color]::White  # White text
    $script:dgvItems.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold header background
    $script:dgvItems.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)   # Dark maroon header text
    $script:dgvItems.ColumnHeadersDefaultCellStyle.Font = Get-HuntFont -Size 10
    $script:dgvItems.EnableHeadersVisualStyles = $false
    $script:dgvItems.GridColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold grid lines
    $script:dgvItems.ColumnHeadersHeight = 28
    
    $null = $script:dgvItems.Columns.Add("Item", "Item")
    $null = $script:dgvItems.Columns.Add("Source", "Boss")
    $null = $script:dgvItems.Columns.Add("Mission", "Mission/Location")
    $null = $script:dgvItems.Columns.Add("Type", "Type")
    $null = $script:dgvItems.Columns.Add("Pts", "Pts")
    
    $script:dgvItems.Columns["Pts"].Width = 40
    $script:dgvItems.Columns["Type"].Width = 70
    $script:dgvItems.Columns["Mission"].Width = 150
    
    # Collected Drops (right side)
    $grpDrops = New-Object System.Windows.Forms.GroupBox
    $grpDrops.Text = "Collected Drops"
    $grpDrops.Location = New-Object System.Drawing.Point(520, 65)
    $grpDrops.Size = New-Object System.Drawing.Size(320, 330)
    $grpDrops.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $grpDrops.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold title
    $grpDrops.Font = Get-HuntFont -Size 12
    $grpDrops.BackColor = $theme.Surface
    
    $script:dgvDrops = New-Object System.Windows.Forms.DataGridView
    $script:dgvDrops.Location = New-Object System.Drawing.Point(10, 25)
    $script:dgvDrops.Size = New-Object System.Drawing.Size(300, 260)
    $script:dgvDrops.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:dgvDrops.AllowUserToAddRows = $false
    $script:dgvDrops.AllowUserToDeleteRows = $false
    $script:dgvDrops.ReadOnly = $true
    $script:dgvDrops.SelectionMode = 'FullRowSelect'
    $script:dgvDrops.RowHeadersVisible = $false
    $script:dgvDrops.AutoSizeColumnsMode = 'Fill'
    $script:dgvDrops.BackgroundColor = $theme.Surface
    $script:dgvDrops.DefaultCellStyle.BackColor = $theme.Surface
    $script:dgvDrops.DefaultCellStyle.ForeColor = [System.Drawing.Color]::White  # White text
    $script:dgvDrops.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold header
    $script:dgvDrops.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)   # Dark maroon
    $script:dgvDrops.ColumnHeadersDefaultCellStyle.Font = Get-HuntFont -Size 10
    $script:dgvDrops.EnableHeadersVisualStyles = $false
    $script:dgvDrops.GridColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold grid lines
    $script:dgvDrops.ColumnHeadersHeight = 28
    
    $null = $script:dgvDrops.Columns.Add("Time", "Session")
    $null = $script:dgvDrops.Columns.Add("Item", "Item")
    $null = $script:dgvDrops.Columns.Add("Boss", "Boss")
    $null = $script:dgvDrops.Columns.Add("Pts", "Pts")
    
    $script:dgvDrops.Columns["Time"].Width = 55
    $script:dgvDrops.Columns["Pts"].Width = 55
    
    $btnRemoveDrop = New-Object System.Windows.Forms.Button
    $btnRemoveDrop.Text = "Remove Selected"
    $btnRemoveDrop.Location = New-Object System.Drawing.Point(10, 290)
    $btnRemoveDrop.Size = New-Object System.Drawing.Size(300, 30)
    $btnRemoveDrop.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnRemoveDrop.FlatStyle = 'Flat'
    $btnRemoveDrop.BackColor = $theme.Warning
    $btnRemoveDrop.ForeColor = [System.Drawing.Color]::White
    $btnRemoveDrop.Add_Click({
        if ($script:dgvDrops.SelectedRows.Count -gt 0) {
            $idx = $script:dgvDrops.SelectedRows[0].Index
            $sortedDrops = @($script:Session.Drops | Sort-Object { [DateTime]::Parse($_.Timestamp) } -Descending)
            if ($idx -lt $sortedDrops.Count) {
                $removedDrop = $sortedDrops[$idx]
                $script:Session.TotalScore -= $removedDrop.Points
                $script:Session.Drops = @($script:Session.Drops | Where-Object { $_.Timestamp -ne $removedDrop.Timestamp })
                $script:sessionDataDirty = $true; Save-SessionData
                Update-ScoreDisplay
                Update-DropsGrid
                Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text
            }
        }
    })
    
    $grpDrops.Controls.AddRange(@($script:dgvDrops, $btnRemoveDrop))
    
    # Bottom panel for buttons
    $script:pnlButtons = New-Object System.Windows.Forms.Panel
    $script:pnlButtons.Location = New-Object System.Drawing.Point(10, 400)
    $script:pnlButtons.Size = New-Object System.Drawing.Size(850, 55)
    $script:pnlButtons.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    
    $btnRecordSelected = New-Object System.Windows.Forms.Button
    $btnRecordSelected.Text = "Record Selected Item (F5)"
    $btnRecordSelected.Location = New-Object System.Drawing.Point(0, 10)
    $btnRecordSelected.Size = New-Object System.Drawing.Size(200, 40)
    $btnRecordSelected.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Bright gold
    $btnRecordSelected.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)   # Dark maroon
    $btnRecordSelected.FlatStyle = 'Flat'
    $btnRecordSelected.Font = Get-HuntFont -Size 12
    $btnRecordSelected.Add_Click({
        if ($script:dgvItems.SelectedRows.Count -gt 0) {
            $allItems = Get-FilteredItems
            $recordedNames = @()
            $dropTimestamps = @()
            
            # Collect all selected items
            $selectedItems = @()
            foreach ($row in $script:dgvItems.SelectedRows) {
                $itemName = $row.Cells["Item"].Value
                $item = $allItems | Where-Object { $_.ItemName -eq $itemName.Trim() } | Select-Object -First 1
                if ($item) { $selectedItems += $item }
            }
            
            # Record each drop
            # For multi-select (rapid drops), skip source selector when there's only one source
            $isMultiSelect = ($selectedItems.Count -gt 1)
            foreach ($selectedItem in $selectedItems) {
                $source = $selectedItem.Source

                # Only show source selector if the item has multiple boss sources (contains /)
                if ($source -and $source -match '/' -and -not $isMultiSelect) {
                    $selectedSource = Show-SourceSelector -ItemName $selectedItem.ItemName -DefaultSource $source
                    if (-not $selectedSource) { continue }
                    $selectedItem | Add-Member -NotePropertyName "SelectedSource" -NotePropertyValue $selectedSource -Force
                } elseif ($source -and $source -match '/') {
                    # Multi-select with multiple sources: use first source automatically
                    $firstSource = ($source -split '/')[0].Trim()
                    $selectedItem | Add-Member -NotePropertyName "SelectedSource" -NotePropertyValue $firstSource -Force
                }

                $drop = Record-Drop -Item $selectedItem
                if ($drop) {
                    $recordedNames += $selectedItem.ItemName
                    $dropTimestamps += $drop.Timestamp
                }
            }
            
            if ($recordedNames.Count -gt 0) {
                Update-ScoreDisplay
                Update-DropsGrid
                Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text
                
                # Auto-clip once for all drops (same moment in time)
                if ($script:Config.AutoClipOnDrop) {
                    Start-Sleep -Milliseconds 500
                    $clipItemNames = $recordedNames -join ", "
                    $clipResult = Request-Clip -Platform "Twitch" -ItemName $clipItemNames
                    if ($clipResult.Success) {
                        # Link clip to ALL drops just recorded
                        foreach ($ts in $dropTimestamps) {
                            for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                                if ($script:Session.Drops[$i].Timestamp -eq $ts) {
                                    $script:Session.Drops[$i].ClipUrl = $clipResult.ClipUrl
                                    break
                                }
                            }
                        }
                        $script:sessionDataDirty = $true; Save-SessionData
                        Update-ClipsList
                        Update-DropsGrid
                        
                        if ($recordedNames.Count -gt 1) {
                            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "$($recordedNames.Count) drops recorded and clip linked!`n`nDrops: $clipItemNames`n$($clipResult.ClipUrl)", "Multi-Drop Recorded", "OK", "Information")
                        } else {
                            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip created and linked!`n$($clipResult.ClipUrl)`n`nClip editor opened - title copied to clipboard!", "Clip Created", "OK", "Information")
                        }
                    } elseif ($clipResult.Error) {
                        [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Auto-clip failed: $($clipResult.Error)", "Clip Failed", "OK", "Warning")
                    }
                } elseif ($recordedNames.Count -gt 1) {
                    [System.Windows.Forms.MessageBox]::Show($script:MainForm, "$($recordedNames.Count) drops recorded!`n`n$($recordedNames -join "`n")", "Multi-Drop Recorded", "OK", "Information")
                }
            }
        }
    })
    
    $btnQuickLog = New-Object System.Windows.Forms.Button
    $btnQuickLog.Text = "Quick Log (F7)"
    $btnQuickLog.Location = New-Object System.Drawing.Point(220, 10)
    $btnQuickLog.Size = New-Object System.Drawing.Size(150, 40)
    $btnQuickLog.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Golden yellow
    $btnQuickLog.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)    # Dark maroon
    $btnQuickLog.FlatStyle = 'Flat'
    $btnQuickLog.Font = Get-HuntFont -Size 12
    $btnQuickLog.Add_Click({ Show-QuickDropDialog; Update-DropsGrid; Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text })
    
    $btnCreateClip = New-Object System.Windows.Forms.Button
    $btnCreateClip.Text = "Create Clip (F6)"
    $btnCreateClip.Location = New-Object System.Drawing.Point(380, 10)
    $btnCreateClip.Size = New-Object System.Drawing.Size(150, 40)
    $btnCreateClip.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)   # Maroon
    $btnCreateClip.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold text
    $btnCreateClip.FlatStyle = 'Flat'
    $btnCreateClip.Font = Get-HuntFont -Size 12
    $btnCreateClip.Add_Click({
        # Use most recent drop for the clip
        $itemName = ""
        $mostRecentIndex = -1
        if ($script:Session.Drops.Count -gt 0) {
            # Find most recent drop
            $mostRecentTimestamp = $null
            for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                $dropTime = [DateTime]::Parse($script:Session.Drops[$i].Timestamp)
                if ($null -eq $mostRecentTimestamp -or $dropTime -gt $mostRecentTimestamp) {
                    $mostRecentTimestamp = $dropTime
                    $mostRecentIndex = $i
                }
            }
            if ($mostRecentIndex -ge 0) {
                $itemName = $script:Session.Drops[$mostRecentIndex].ItemName
            }
        }
        
        $clipResult = New-TwitchClip -Title "Hunt Drop: $itemName"
        if ($clipResult.Success) {
            # Link clip to the most recent drop
            if ($mostRecentIndex -ge 0) {
                $script:Session.Drops[$mostRecentIndex].ClipUrl = $clipResult.ClipUrl
            }
            
            $script:Session.ClipLinks += @{
                Platform = "Twitch"
                Url = $clipResult.ClipUrl
                Item = $itemName
                Timestamp = (Get-Date).ToString("o")
            }
            $script:sessionDataDirty = $true; Save-SessionData
            Update-ClipsList
            Update-DropsGrid
            
            # Copy clip title to clipboard for easy renaming
            $clipTitle = "Hunt Drop: $itemName"
            [System.Windows.Forms.Clipboard]::SetText($clipTitle)
            
            # Open clip editor in browser so user can rename the clip
            if ($clipResult.EditUrl) {
                Start-Process $clipResult.EditUrl
            }
            
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip created and linked to: $itemName`n$($clipResult.ClipUrl)`n`nClip editor opened - title copied to clipboard!", "Clip Created")
        } else {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Failed to create clip: $($clipResult.Error)", "Clip Error")
        }
    })
    
    $script:pnlButtons.Controls.AddRange(@($btnRecordSelected, $btnQuickLog, $btnCreateClip))
    
    # Filter event handlers - use script-scope variables
    $script:txtSearch.Add_TextChanged({ Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text })
    $script:cmbCategory.Add_SelectedIndexChanged({ Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text })
    $script:cmbGameMode.Add_SelectedIndexChanged({ Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text })
    $script:cmbBoss.Add_SelectedIndexChanged({ Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text })
    
    # Add controls - grpDrops last so it's on top
    $tabTracking.Controls.Add($script:pnlFilters)
    $tabTracking.Controls.Add($script:pnlButtons)
    $tabTracking.Controls.Add($script:dgvItems)
    $tabTracking.Controls.Add($grpDrops)
    $grpDrops.BringToFront()
    
    # Store reference for resize handler
    $script:grpDrops = $grpDrops
    
    # Resize handler to adjust layout when window size changes
    $tabTracking.Add_Resize({
        param($sender, $e)
        
        $tabWidth = $sender.ClientSize.Width
        $tabHeight = $sender.ClientSize.Height
        
        # Calculate available width (subtract padding)
        $availWidth = $tabWidth - 20
        
        # Collected Drops panel - fixed width 320, anchored to right
        $dropsWidth = 320
        $script:grpDrops.Location = New-Object System.Drawing.Point(($availWidth - $dropsWidth + 10), 65)
        $script:grpDrops.Size = New-Object System.Drawing.Size($dropsWidth, ($tabHeight - 130))
        
        # Items grid - fill remaining space on left
        $itemsWidth = $availWidth - $dropsWidth - 20
        $script:dgvItems.Size = New-Object System.Drawing.Size($itemsWidth, ($tabHeight - 130))
        
        # Buttons panel - stay at bottom
        $script:pnlButtons.Location = New-Object System.Drawing.Point(10, ($tabHeight - 60))
        $script:pnlButtons.Size = New-Object System.Drawing.Size($availWidth, 55)
    })
    #endregion
    
    #region Clips Tab
    $tabClips = New-Object System.Windows.Forms.TabPage
    $tabClips.Text = "Clips"
    $tabClips.BackColor = $theme.Background
    
    $btnCreateTwitchClip = New-Object System.Windows.Forms.Button
    $btnCreateTwitchClip.Text = "Create Twitch Clip (F6)"
    $btnCreateTwitchClip.Location = New-Object System.Drawing.Point(20, 10)
    $btnCreateTwitchClip.Size = New-Object System.Drawing.Size(200, 40)
    $btnCreateTwitchClip.BackColor = [System.Drawing.Color]::FromArgb(145, 70, 255)
    $btnCreateTwitchClip.ForeColor = [System.Drawing.Color]::White
    $btnCreateTwitchClip.FlatStyle = 'Flat'
    $btnCreateTwitchClip.Add_Click({
        # Ask which drop this clip is for
        $itemName = ""
        if ($script:Session.Drops.Count -gt 0) {
            $pickForm = New-Object System.Windows.Forms.Form
            $pickForm.Text = "Link Clip to Drop"
            $pickForm.Size = New-Object System.Drawing.Size(350, 200)
            $pickForm.StartPosition = 'CenterParent'
            $pickForm.FormBorderStyle = 'FixedDialog'
            $pickForm.MaximizeBox = $false
            $pickForm.BackColor = [System.Drawing.Color]::FromArgb(66, 4, 21)
            
            $lblPick = New-Object System.Windows.Forms.Label
            $lblPick.Text = "Which drop is this clip for?"
            $lblPick.Location = New-Object System.Drawing.Point(20, 15)
            $lblPick.Size = New-Object System.Drawing.Size(300, 20)
            $lblPick.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
            
            $cmbDrops = New-Object System.Windows.Forms.ComboBox
            $cmbDrops.Location = New-Object System.Drawing.Point(20, 40)
            $cmbDrops.Size = New-Object System.Drawing.Size(290, 25)
            $cmbDrops.DropDownStyle = 'DropDownList'
            $cmbDrops.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)
            $cmbDrops.ForeColor = [System.Drawing.Color]::White
            
            # Add recent drops (newest first)
            $recentDrops = $script:Session.Drops | Sort-Object { [DateTime]::Parse($_.Timestamp) } -Descending | Select-Object -First 10
            foreach ($drop in $recentDrops) {
                [void]$cmbDrops.Items.Add($drop.ItemName)
            }
            [void]$cmbDrops.Items.Add("(No specific drop)")
            $cmbDrops.SelectedIndex = 0
            
            $btnOK = New-Object System.Windows.Forms.Button
            $btnOK.Text = "Create Clip"
            $btnOK.Location = New-Object System.Drawing.Point(20, 110)
            $btnOK.Size = New-Object System.Drawing.Size(120, 35)
            $btnOK.BackColor = [System.Drawing.Color]::FromArgb(145, 70, 255)
            $btnOK.ForeColor = [System.Drawing.Color]::White
            $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
            
            $btnCancel = New-Object System.Windows.Forms.Button
            $btnCancel.Text = "Cancel"
            $btnCancel.Location = New-Object System.Drawing.Point(160, 110)
            $btnCancel.Size = New-Object System.Drawing.Size(100, 35)
            $btnCancel.BackColor = [System.Drawing.Color]::FromArgb(100, 100, 100)
            $btnCancel.ForeColor = [System.Drawing.Color]::White
            $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            
            $pickForm.Controls.AddRange(@($lblPick, $cmbDrops, $btnOK, $btnCancel))
            $pickForm.AcceptButton = $btnOK
            $pickForm.CancelButton = $btnCancel
            
            if ($pickForm.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                if ($cmbDrops.SelectedItem -ne "(No specific drop)") {
                    $itemName = $cmbDrops.SelectedItem
                }
            } else {
                return
            }
        }
        
        $result = Request-Clip -Platform "Twitch" -ItemName $itemName
        if ($result.Success) {
            Update-ClipsList
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip created!`n$($result.ClipUrl)", "Success")
            [System.Windows.Forms.Clipboard]::SetText($result.ClipUrl)
        } else {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip failed: $($result.Error)", "Error")
        }
    })
    
    $btnCreateKickClip = New-Object System.Windows.Forms.Button
    $btnCreateKickClip.Text = "Kick Clip (Manual)"
    $btnCreateKickClip.Location = New-Object System.Drawing.Point(230, 10)
    $btnCreateKickClip.Size = New-Object System.Drawing.Size(200, 40)
    $btnCreateKickClip.BackColor = [System.Drawing.Color]::FromArgb(83, 252, 24)
    $btnCreateKickClip.ForeColor = [System.Drawing.Color]::Black
    $btnCreateKickClip.FlatStyle = 'Flat'
    $btnCreateKickClip.Add_Click({
        if ($script:Config.KickChannelName) {
            Start-Process "https://kick.com/$($script:Config.KickChannelName)"
        } else {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Please configure your Kick channel name in Settings", "Not Configured")
        }
    })
    
    $lblClipList = New-Object System.Windows.Forms.Label
    $lblClipList.Text = "Recorded Clips:"
    $lblClipList.Location = New-Object System.Drawing.Point(20, 95)
    $lblClipList.AutoSize = $true
    $lblClipList.ForeColor = $theme.Text
    
    $script:lstClips = New-Object System.Windows.Forms.ListBox
    $script:lstClips.Location = New-Object System.Drawing.Point(20, 115)
    $script:lstClips.Size = New-Object System.Drawing.Size(900, 380)
    $script:lstClips.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $script:lstClips.BackColor = $theme.Surface
    $script:lstClips.ForeColor = $theme.Text
    
    # Double-click to copy URL
    $script:lstClips.Add_DoubleClick({
        if ($script:lstClips.SelectedIndex -ge 0 -and $script:lstClips.SelectedIndex -lt $script:Session.ClipLinks.Count) {
            $clip = $script:Session.ClipLinks[$script:lstClips.SelectedIndex]
            [System.Windows.Forms.Clipboard]::SetText($clip.Url)
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "URL copied to clipboard!`n$($clip.Url)", "Copied", "OK", "Information")
        }
    })
    
    # Initial load
    Update-ClipsList
    
    $btnCopyClipUrl = New-Object System.Windows.Forms.Button
    $btnCopyClipUrl.Text = "Copy Selected URL"
    $btnCopyClipUrl.Location = New-Object System.Drawing.Point(20, 55)
    $btnCopyClipUrl.Size = New-Object System.Drawing.Size(160, 35)
    $btnCopyClipUrl.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    $btnCopyClipUrl.ForeColor = [System.Drawing.Color]::FromArgb(66, 4, 21)    # Dark maroon
    $btnCopyClipUrl.FlatStyle = 'Flat'
    $btnCopyClipUrl.Font = Get-HuntFont -Size 10
    $btnCopyClipUrl.Add_Click({
        if ($script:lstClips.SelectedIndex -ge 0 -and $script:lstClips.SelectedIndex -lt $script:Session.ClipLinks.Count) {
            $clip = $script:Session.ClipLinks[$script:lstClips.SelectedIndex]
            [System.Windows.Forms.Clipboard]::SetText($clip.Url)
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "URL copied to clipboard!", "Copied")
        }
    })
    
    # Remove Selected Clip button
    $btnRemoveSelectedClip = New-Object System.Windows.Forms.Button
    $btnRemoveSelectedClip.Text = "Remove Selected"
    $btnRemoveSelectedClip.Location = New-Object System.Drawing.Point(190, 55)
    $btnRemoveSelectedClip.Size = New-Object System.Drawing.Size(150, 35)
    $btnRemoveSelectedClip.BackColor = [System.Drawing.Color]::FromArgb(200, 50, 50)  # Red
    $btnRemoveSelectedClip.ForeColor = [System.Drawing.Color]::White
    $btnRemoveSelectedClip.FlatStyle = 'Flat'
    $btnRemoveSelectedClip.Font = Get-HuntFont -Size 10
    $btnRemoveSelectedClip.Add_Click({
        if ($script:lstClips.SelectedIndex -lt 0 -or $script:lstClips.SelectedIndex -ge $script:Session.ClipLinks.Count) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Select a clip from the list first.", "No Selection")
            return
        }
        
        $clipIndex = $script:lstClips.SelectedIndex
        $clip = $script:Session.ClipLinks[$clipIndex]
        
        $confirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "Remove this clip?`n`n[$($clip.Platform)] $($clip.Item)`n$($clip.Url)`n`nThis will also unlink it from the drop.",
            "Confirm Remove",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        
        if ($confirm -eq 'Yes') {
            # Remove from ClipLinks array using URL match (reliable comparison)
            $urlToRemove = $clip.Url
            $itemToRemove = $clip.Item
            $script:Session.ClipLinks = @($script:Session.ClipLinks | Where-Object { 
                -not ($_.Url -eq $urlToRemove -and $_.Item -eq $itemToRemove)
            })
            
            # Also clear ClipUrl from any drop that has this URL
            for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                if ($script:Session.Drops[$i].ClipUrl -eq $urlToRemove) {
                    $script:Session.Drops[$i].ClipUrl = ""
                    $script:Session.Drops[$i].Submitted = $false
                }
            }
            
            $script:sessionDataDirty = $true; Save-SessionData
            Update-ClipsList
            Update-DropsGrid
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip removed and unlinked from drop.", "Removed")
        }
    })
    
    # Manual clip linking button
    $btnLinkClip = New-Object System.Windows.Forms.Button
    $btnLinkClip.Text = "Link / Edit Clip"
    $btnLinkClip.Location = New-Object System.Drawing.Point(440, 10)
    $btnLinkClip.Size = New-Object System.Drawing.Size(200, 40)
    $btnLinkClip.BackColor = $theme.Gold
    $btnLinkClip.ForeColor = [System.Drawing.Color]::Black
    $btnLinkClip.FlatStyle = 'Flat'
    $btnLinkClip.Add_Click({
        if ($script:Session.Drops.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "No drops recorded yet!", "No Drops", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            return
        }
        
        # Show ALL drops - both with and without clips
        $allDropsList = @()
        for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
            $drop = $script:Session.Drops[$i]
            $dropTime = ""
            if ($drop.Timestamp -and $script:SessionTimerStart) {
                try {
                    $dropDateTime = [DateTime]::Parse($drop.Timestamp)
                    $elapsed = $dropDateTime - $script:SessionTimerStart
                    if ($elapsed.TotalSeconds -ge 0) {
                        $dropTime = " @ {0:00}:{1:00}:{2:00}" -f [Math]::Floor($elapsed.TotalHours), $elapsed.Minutes, $elapsed.Seconds
                    }
                } catch { }
            }
            $clipStatus = if ($drop.ClipUrl -and $drop.ClipUrl -ne "") { " [HAS CLIP]" } else { " [NO CLIP]" }
            $allDropsList += @{ Index = $i; Drop = $drop; TimeStr = $dropTime; ClipStatus = $clipStatus }
        }
        
        # Show dialog to link/edit clip
        $linkForm = New-Object System.Windows.Forms.Form
        $linkForm.Text = "Link / Edit Clip"
        $linkForm.Size = New-Object System.Drawing.Size(500, 320)
        $linkForm.StartPosition = 'CenterParent'
        $linkForm.FormBorderStyle = 'FixedDialog'
        $linkForm.MaximizeBox = $false
        $linkForm.BackColor = [System.Drawing.Color]::FromArgb(66, 4, 21)
        
        $lblSelect = New-Object System.Windows.Forms.Label
        $lblSelect.Text = "Select drop to link or change clip:"
        $lblSelect.Location = New-Object System.Drawing.Point(20, 15)
        $lblSelect.Size = New-Object System.Drawing.Size(400, 20)
        $lblSelect.ForeColor = [System.Drawing.Color]::White
        
        $cmbDrops = New-Object System.Windows.Forms.ComboBox
        $cmbDrops.Location = New-Object System.Drawing.Point(20, 40)
        $cmbDrops.Size = New-Object System.Drawing.Size(440, 25)
        $cmbDrops.DropDownStyle = 'DropDownList'
        $cmbDrops.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)
        $cmbDrops.ForeColor = [System.Drawing.Color]::White
        
        foreach ($item in $allDropsList) {
            [void]$cmbDrops.Items.Add("$($item.Drop.ItemName)$($item.TimeStr)$($item.ClipStatus)")
        }
        $cmbDrops.SelectedIndex = 0
        
        # Show current clip URL when selection changes
        $lblCurrentClip = New-Object System.Windows.Forms.Label
        $lblCurrentClip.Location = New-Object System.Drawing.Point(20, 72)
        $lblCurrentClip.Size = New-Object System.Drawing.Size(440, 20)
        $lblCurrentClip.ForeColor = [System.Drawing.Color]::FromArgb(255, 248, 166)
        $lblCurrentClip.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        
        $updateCurrentLabel = {
            $sel = $allDropsList[$cmbDrops.SelectedIndex]
            if ($sel.Drop.ClipUrl -and $sel.Drop.ClipUrl -ne "") {
                $lblCurrentClip.Text = "Current: $($sel.Drop.ClipUrl)"
            } else {
                $lblCurrentClip.Text = "Current: (no clip)"
            }
        }
        & $updateCurrentLabel
        $cmbDrops.Add_SelectedIndexChanged({ & $updateCurrentLabel })
        
        $lblUrl = New-Object System.Windows.Forms.Label
        $lblUrl.Text = "Paste new clip URL:"
        $lblUrl.Location = New-Object System.Drawing.Point(20, 100)
        $lblUrl.Size = New-Object System.Drawing.Size(200, 20)
        $lblUrl.ForeColor = [System.Drawing.Color]::White
        
        $txtClipUrl = New-Object System.Windows.Forms.TextBox
        $txtClipUrl.Location = New-Object System.Drawing.Point(20, 125)
        $txtClipUrl.Size = New-Object System.Drawing.Size(440, 25)
        $txtClipUrl.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)
        $txtClipUrl.ForeColor = [System.Drawing.Color]::White
        
        $lblHint = New-Object System.Windows.Forms.Label
        $lblHint.Text = "Supports: Twitch clips, Kick clips, YouTube links"
        $lblHint.Location = New-Object System.Drawing.Point(20, 155)
        $lblHint.Size = New-Object System.Drawing.Size(400, 20)
        $lblHint.ForeColor = [System.Drawing.Color]::FromArgb(255, 248, 166)
        
        $btnLink = New-Object System.Windows.Forms.Button
        $btnLink.Text = "Link / Update Clip"
        $btnLink.Location = New-Object System.Drawing.Point(20, 190)
        $btnLink.Size = New-Object System.Drawing.Size(150, 40)
        $btnLink.BackColor = [System.Drawing.Color]::FromArgb(255, 198, 0)
        $btnLink.ForeColor = [System.Drawing.Color]::Black
        $btnLink.FlatStyle = 'Flat'
        
        $btnRemoveClip = New-Object System.Windows.Forms.Button
        $btnRemoveClip.Text = "Remove Clip"
        $btnRemoveClip.Location = New-Object System.Drawing.Point(190, 190)
        $btnRemoveClip.Size = New-Object System.Drawing.Size(120, 40)
        $btnRemoveClip.BackColor = [System.Drawing.Color]::FromArgb(200, 50, 50)
        $btnRemoveClip.ForeColor = [System.Drawing.Color]::White
        $btnRemoveClip.FlatStyle = 'Flat'
        
        $btnCancelLink = New-Object System.Windows.Forms.Button
        $btnCancelLink.Text = "Cancel"
        $btnCancelLink.Location = New-Object System.Drawing.Point(330, 190)
        $btnCancelLink.Size = New-Object System.Drawing.Size(100, 40)
        $btnCancelLink.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)
        $btnCancelLink.ForeColor = [System.Drawing.Color]::White
        $btnCancelLink.FlatStyle = 'Flat'
        $btnCancelLink.Add_Click({ $linkForm.Close() })
        
        $btnRemoveClip.Add_Click({
            $selectedItem = $allDropsList[$cmbDrops.SelectedIndex]
            $dropIndex = $selectedItem.Index
            $dropClipUrl = $script:Session.Drops[$dropIndex].ClipUrl
            $dropItemName = $selectedItem.Drop.ItemName
            
            # Check both the drop and ClipLinks for this item
            $hasClipOnDrop = $dropClipUrl -and $dropClipUrl -ne ""
            $hasClipInLinks = $script:Session.ClipLinks | Where-Object { $_.Item -eq $dropItemName }
            
            if (-not $hasClipOnDrop -and -not $hasClipInLinks) {
                [System.Windows.Forms.MessageBox]::Show($script:MainForm, "This drop doesn't have a clip to remove.", "No Clip")
                return
            }
            
            $confirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "Remove clip from '$dropItemName'?",
                "Confirm Remove",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )
            if ($confirm -eq 'Yes') {
                # Clear ClipUrl on the drop
                $script:Session.Drops[$dropIndex].ClipUrl = ""
                $script:Session.Drops[$dropIndex].Submitted = $false
                
                # Also remove ALL matching entries from ClipLinks
                $urlToRemove = $dropClipUrl
                $script:Session.ClipLinks = @($script:Session.ClipLinks | Where-Object { 
                    $_.Item -ne $dropItemName -and $_.Url -ne $urlToRemove
                })
                
                $script:sessionDataDirty = $true; Save-SessionData
                Update-ClipsList
                Update-DropsGrid
                [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip removed from $dropItemName", "Removed")
                $linkForm.Close()
            }
        })
        
        $btnLink.Add_Click({
            $clipUrl = $txtClipUrl.Text.Trim()
            if ([string]::IsNullOrWhiteSpace($clipUrl)) {
                [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Please enter a clip URL", "Missing URL")
                return
            }
            
            # Validate URL format
            if ($clipUrl -notmatch "^https?://") {
                [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Please enter a valid URL starting with http:// or https://", "Invalid URL")
                return
            }
            
            # Get selected drop
            $selectedItem = $allDropsList[$cmbDrops.SelectedIndex]
            $dropIndex = $selectedItem.Index
            $hadClip = $script:Session.Drops[$dropIndex].ClipUrl -and $script:Session.Drops[$dropIndex].ClipUrl -ne ""
            
            # Update the drop with clip URL
            $script:Session.Drops[$dropIndex].ClipUrl = $clipUrl
            
            # Detect platform
            $platform = "Other"
            if ($clipUrl -match "twitch\.tv") { $platform = "Twitch" }
            elseif ($clipUrl -match "kick\.com") { $platform = "Kick" }
            elseif ($clipUrl -match "youtube\.com|youtu\.be") { $platform = "YouTube" }
            
            # Add to clip links
            $script:Session.ClipLinks += @{
                Url = $clipUrl
                Timestamp = (Get-Date).ToString("o")
                Platform = $platform
                Item = $selectedItem.Drop.ItemName
            }
            
            $script:sessionDataDirty = $true; Save-SessionData
            Update-ClipsList
            Update-DropsGrid
            
            $action = if ($hadClip) { "updated" } else { "linked" }
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip $action for $($selectedItem.Drop.ItemName)!", "Success")
            $linkForm.Close()
        })
        
        $linkForm.Controls.AddRange(@($lblSelect, $cmbDrops, $lblCurrentClip, $lblUrl, $txtClipUrl, $lblHint, $btnLink, $btnRemoveClip, $btnCancelLink))
        $linkForm.ShowDialog()
    })
    
    # Purge orphaned clips button
    $btnPurgeClips = New-Object System.Windows.Forms.Button
    $btnPurgeClips.Text = "Purge Orphaned Clips"
    $btnPurgeClips.Location = New-Object System.Drawing.Point(350, 55)
    $btnPurgeClips.Size = New-Object System.Drawing.Size(180, 35)
    $btnPurgeClips.BackColor = [System.Drawing.Color]::FromArgb(152, 10, 49)
    $btnPurgeClips.ForeColor = [System.Drawing.Color]::White
    $btnPurgeClips.FlatStyle = 'Flat'
    $btnPurgeClips.Font = Get-HuntFont -Size 9
    $btnPurgeClips.Add_Click({
        # Find clips in ClipLinks that don't match any drop's ClipUrl
        $validUrls = @($script:Session.Drops | Where-Object { $_.ClipUrl -and $_.ClipUrl -ne "" } | ForEach-Object { $_.ClipUrl })
        $orphaned = @($script:Session.ClipLinks | Where-Object { $_.Url -and $_.Url -notin $validUrls })
        
        if ($orphaned.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "No orphaned clips found. Everything is clean!", "All Good", "OK", "Information")
            return
        }
        
        $confirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "Found $($orphaned.Count) orphaned clip(s) not linked to any drop.`n`nRemove them?",
            "Purge Orphaned Clips",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        
        if ($confirm -eq 'Yes') {
            $script:Session.ClipLinks = @($script:Session.ClipLinks | Where-Object { $_.Url -in $validUrls })
            $script:sessionDataDirty = $true; Save-SessionData
            Update-ClipsList
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Removed $($orphaned.Count) orphaned clip(s).", "Purged")
        }
    })
    
    $tabClips.Controls.AddRange(@($btnCreateTwitchClip, $btnCreateKickClip, $btnRemoveSelectedClip, $btnLinkClip, $lblClipList, $script:lstClips, $btnCopyClipUrl, $btnPurgeClips))
    #endregion
    
    #region Export Tab
    $tabExport = New-Object System.Windows.Forms.TabPage
    $tabExport.Text = "Export & Submit"
    $tabExport.BackColor = $theme.Background
    
    $grpExport = New-Object System.Windows.Forms.GroupBox
    $grpExport.Text = "Export Session Data"
    $grpExport.Location = New-Object System.Drawing.Point(20, 20)
    $grpExport.Size = New-Object System.Drawing.Size(400, 150)
    $grpExport.ForeColor = $theme.Text
    
    $btnExportJson = New-Object System.Windows.Forms.Button
    $btnExportJson.Text = "Export to JSON"
    $btnExportJson.Location = New-Object System.Drawing.Point(20, 30)
    $btnExportJson.Size = New-Object System.Drawing.Size(150, 40)
    $btnExportJson.BackColor = $theme.Surface
    $btnExportJson.ForeColor = $theme.Text
    $btnExportJson.FlatStyle = 'Flat'
    $btnExportJson.Add_Click({
        $saveDialog = New-Object System.Windows.Forms.SaveFileDialog
        $saveDialog.Filter = "JSON Files (*.json)|*.json"
        $saveDialog.FileName = "hunt_session_$($script:Session.PlayerName)_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        if ($saveDialog.ShowDialog() -eq 'OK') {
            Export-SessionToJson -FilePath $saveDialog.FileName
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Exported to: $($saveDialog.FileName)", "Export Complete")
        }
    })
    
    $btnExportCsv = New-Object System.Windows.Forms.Button
    $btnExportCsv.Text = "Export to CSV"
    $btnExportCsv.Location = New-Object System.Drawing.Point(200, 30)
    $btnExportCsv.Size = New-Object System.Drawing.Size(150, 40)
    $btnExportCsv.BackColor = $theme.Surface
    $btnExportCsv.ForeColor = $theme.Text
    $btnExportCsv.FlatStyle = 'Flat'
    $btnExportCsv.Add_Click({
        $saveDialog = New-Object System.Windows.Forms.SaveFileDialog
        $saveDialog.Filter = "CSV Files (*.csv)|*.csv"
        $saveDialog.FileName = "hunt_drops_$($script:Session.PlayerName)_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        if ($saveDialog.ShowDialog() -eq 'OK') {
            Export-SessionToCsv -FilePath $saveDialog.FileName
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Exported to: $($saveDialog.FileName)", "Export Complete")
        }
    })
    
    $btnClearSession = New-Object System.Windows.Forms.Button
    $btnClearSession.Text = "Clear Session"
    $btnClearSession.Location = New-Object System.Drawing.Point(20, 90)
    $btnClearSession.Size = New-Object System.Drawing.Size(150, 40)
    $btnClearSession.BackColor = $theme.Warning
    $btnClearSession.ForeColor = [System.Drawing.Color]::White
    $btnClearSession.FlatStyle = 'Flat'
    $btnClearSession.Add_Click({
        $confirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
            "Are you sure you want to clear all session data?`nThis cannot be undone!",
            "Confirm Clear",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($confirm -eq 'Yes') {
            $script:Session = @{
                PlayerName = $script:Session.PlayerName
                StartTime = $null
                Drops = @()
                TotalScore = 0
                ClipLinks = @()
            }
            $script:sessionDataDirty = $true; Save-SessionData
            Update-ScoreDisplay
            Update-DropsGrid
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Session cleared!", "Done")
        }
    })
    
    $grpExport.Controls.AddRange(@($btnExportJson, $btnExportCsv, $btnClearSession))
    
    # Submit to Website
    $grpSubmit = New-Object System.Windows.Forms.GroupBox
    $grpSubmit.Text = "Submit to Hunt Website"
    $grpSubmit.Location = New-Object System.Drawing.Point(20, 190)
    $grpSubmit.Size = New-Object System.Drawing.Size(400, 150)
    $grpSubmit.ForeColor = $theme.Text
    
    # Status label showing submitted vs remaining
    $script:lblSubmitStatus = New-Object System.Windows.Forms.Label
    $script:lblSubmitStatus.Location = New-Object System.Drawing.Point(20, 25)
    $script:lblSubmitStatus.Size = New-Object System.Drawing.Size(350, 40)
    $script:lblSubmitStatus.Font = Get-HuntFont -Size 10
    $submittedCount = @($script:Session.Drops | Where-Object { $_.Submitted }).Count
    $unsubmittedCount = @($script:Session.Drops | Where-Object { (-not $_.Submitted) -and $_.ClipUrl -and $_.ClipUrl -ne "" }).Count
    $missingClips = @($script:Session.Drops | Where-Object { -not $_.ClipUrl -or $_.ClipUrl -eq "" }).Count
    $script:lblSubmitStatus.Text = "Submitted: $submittedCount  |  Ready: $unsubmittedCount  |  Missing Clips: $missingClips"
    
    $btnSubmit = New-Object System.Windows.Forms.Button
    $btnSubmit.Text = "SUBMIT DROPS"
    $btnSubmit.Location = New-Object System.Drawing.Point(20, 70)
    $btnSubmit.Size = New-Object System.Drawing.Size(350, 50)
    $btnSubmit.BackColor = $theme.Success
    $btnSubmit.ForeColor = [System.Drawing.Color]::White
    $btnSubmit.FlatStyle = 'Flat'
    $btnSubmit.Font = Get-HuntFont -Size 14
    $btnSubmit.Add_Click({
        # Check for drops without clips (only unsubmitted ones)
        $dropsWithoutClips = @($script:Session.Drops | Where-Object { 
            (-not $_.Submitted) -and (-not $_.ClipUrl -or $_.ClipUrl -eq "") 
        })
        $unsubmittedWithClips = @($script:Session.Drops | Where-Object { 
            (-not $_.Submitted) -and $_.ClipUrl -and $_.ClipUrl -ne "" 
        })
        $totalDrops = $script:Session.Drops.Count
        
        if ($totalDrops -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "No drops to submit!`n`nRecord some drops first.",
                "No Drops",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            return
        }
        
        if ($unsubmittedWithClips.Count -eq 0 -and $dropsWithoutClips.Count -gt 0) {
            # All unsubmitted drops are missing clips
            $missingList = ($dropsWithoutClips | Select-Object -First 10 | ForEach-Object {
                $dropTime = ""
                if ($_.Timestamp -and $script:SessionTimerStart) {
                    try {
                        $dropDateTime = [DateTime]::Parse($_.Timestamp)
                        $sessionStart = $script:SessionTimerStart
                        $elapsed = $dropDateTime - $sessionStart
                        if ($elapsed.TotalSeconds -ge 0) {
                            $dropTime = " @ {0:00}:{1:00}:{2:00}" -f [Math]::Floor($elapsed.TotalHours), $elapsed.Minutes, $elapsed.Seconds
                        }
                    } catch { }
                }
                "  - $($_.ItemName)$dropTime"
            }) -join "`n"
            
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "All remaining drops are missing clips!`n`n$missingList`n`nAdd clips via F6 or Clips tab, then submit again.",
                "Clips Required",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            return
        }
        
        if ($unsubmittedWithClips.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "All drops have already been submitted!",
                "Already Submitted",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            )
            return
        }
        
        # Warn about drops missing clips but continue with ones that have clips
        if ($dropsWithoutClips.Count -gt 0) {
            $skipConfirm = [System.Windows.Forms.MessageBox]::Show($script:MainForm, 
                "$($dropsWithoutClips.Count) drops are missing clips and will be SKIPPED.`n" +
                "$($unsubmittedWithClips.Count) drops are ready to submit.`n`n" +
                "Continue with the $($unsubmittedWithClips.Count) ready drops?",
                "Some Drops Missing Clips",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            if ($skipConfirm -ne 'Yes') { return }
        }
        
        Submit-ToWebsite
        
        # Update status label
        $submittedCount = @($script:Session.Drops | Where-Object { $_.Submitted }).Count
        $unsubmittedCount = @($script:Session.Drops | Where-Object { (-not $_.Submitted) -and $_.ClipUrl -and $_.ClipUrl -ne "" }).Count
        $missingClips = @($script:Session.Drops | Where-Object { -not $_.ClipUrl -or $_.ClipUrl -eq "" }).Count
        $script:lblSubmitStatus.Text = "Submitted: $submittedCount  |  Ready: $unsubmittedCount  |  Missing Clips: $missingClips"
    })
    
    $grpSubmit.Controls.AddRange(@($script:lblSubmitStatus, $btnSubmit))
    
    # Session Summary
    $grpSummary = New-Object System.Windows.Forms.GroupBox
    $grpSummary.Text = "Session Summary"
    $grpSummary.Location = New-Object System.Drawing.Point(450, 20)
    $grpSummary.Size = New-Object System.Drawing.Size(490, 320)
    $grpSummary.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $grpSummary.ForeColor = $theme.Text
    
    $txtSummary = New-Object System.Windows.Forms.TextBox
    $txtSummary.Location = New-Object System.Drawing.Point(10, 25)
    $txtSummary.Size = New-Object System.Drawing.Size(470, 280)
    $txtSummary.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
    $txtSummary.Multiline = $true
    $txtSummary.ReadOnly = $true
    $txtSummary.ScrollBars = 'Vertical'
    $txtSummary.BackColor = $theme.Surface
    $txtSummary.ForeColor = $theme.Text
    $txtSummary.Font = New-Object System.Drawing.Font("Consolas", 10)
    
    # Build summary text
    $summaryText = @"
=======================================
    THE HUNT - SESSION SUMMARY
=======================================

Player: $($script:Session.PlayerName)
Total Score: $($script:Session.TotalScore)
Total Drops: $($script:Session.Drops.Count)
Clips Recorded: $($script:Session.ClipLinks.Count)

--------------------------------------
DROP BREAKDOWN:
"@
    
    $dropsByBoss = $script:Session.Drops | Group-Object BossName | Sort-Object Count -Descending
    foreach ($group in $dropsByBoss) {
        $summaryText += "`n  $($group.Name): $($group.Count) drops"
    }
    
    $txtSummary.Text = $summaryText
    $grpSummary.Controls.Add($txtSummary)
    
    $tabExport.Controls.AddRange(@($grpExport, $grpSubmit, $grpSummary))
    #endregion
    
    $tabControl.TabPages.AddRange(@($tabTracking, $tabClips, $tabExport))
    #endregion
    
    #region Footer
    $pnlFooter = New-Object System.Windows.Forms.Panel
    $pnlFooter.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $pnlFooter.Height = 30
    $pnlFooter.BackColor = $theme.Surface
    
    $lblHotkeys = New-Object System.Windows.Forms.Label
    $lblHotkeys.Text = "Hotkeys: F5 = Record Drop | F6 = Create Clip | F7 = Quick Log"
    $lblHotkeys.Location = New-Object System.Drawing.Point(20, 5)
    $lblHotkeys.AutoSize = $true
    $lblHotkeys.ForeColor = [System.Drawing.Color]::FromArgb(255, 198, 0)  # Gold
    $lblHotkeys.Font = Get-HuntFont -Size 11
    
    $pnlFooter.Controls.Add($lblHotkeys)
    #endregion
    
    # Add all controls (order matters for docking)
    $form.Controls.Add($tabControl)
    $form.Controls.Add($pnlFooter)
    $form.Controls.Add($pnlHeader)
    
    # Global hotkey handling
    $form.Add_KeyDown({
        param($sender, $e)
        
        switch ($e.KeyCode) {
            $script:Config.RecordDropKey {
                # Record selected items (supports multi-select)
                if ($script:dgvItems.SelectedRows.Count -gt 0) {
                    $allItems = Get-FilteredItems
                    $recordedNames = @()
                    $dropTimestamps = @()
                    
                    foreach ($row in $script:dgvItems.SelectedRows) {
                        $itemName = $row.Cells["Item"].Value
                        $selectedItem = $allItems | Where-Object { $_.ItemName -eq $itemName.Trim() } | Select-Object -First 1
                        if ($selectedItem) {
                            $drop = Record-Drop -Item $selectedItem
                            if ($drop) {
                                $recordedNames += $selectedItem.ItemName
                                $dropTimestamps += $drop.Timestamp
                            }
                        }
                    }
                    
                    if ($recordedNames.Count -gt 0) {
                        Update-ScoreDisplay
                        Update-DropsGrid
                        
                        # Auto-clip once for all drops
                        if ($script:Config.AutoClipOnDrop) {
                            Start-Sleep -Milliseconds 500
                            $clipItemNames = $recordedNames -join ", "
                            $clipResult = Request-Clip -Platform "Twitch" -ItemName $clipItemNames
                            if ($clipResult.Success) {
                                foreach ($ts in $dropTimestamps) {
                                    for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                                        if ($script:Session.Drops[$i].Timestamp -eq $ts) {
                                            $script:Session.Drops[$i].ClipUrl = $clipResult.ClipUrl
                                            break
                                        }
                                    }
                                }
                                $script:sessionDataDirty = $true; Save-SessionData
                                Update-ClipsList
                                Update-DropsGrid
                            }
                        }
                    }
                }
                $e.Handled = $true
            }
            $script:Config.CreateClipKey {
                # Use most recent drop for the clip
                $itemName = ""
                $mostRecentIndex = -1
                if ($script:Session.Drops.Count -gt 0) {
                    # Find most recent drop
                    $mostRecentTimestamp = $null
                    for ($i = 0; $i -lt $script:Session.Drops.Count; $i++) {
                        $dropTime = [DateTime]::Parse($script:Session.Drops[$i].Timestamp)
                        if ($null -eq $mostRecentTimestamp -or $dropTime -gt $mostRecentTimestamp) {
                            $mostRecentTimestamp = $dropTime
                            $mostRecentIndex = $i
                        }
                    }
                    if ($mostRecentIndex -ge 0) {
                        $itemName = $script:Session.Drops[$mostRecentIndex].ItemName
                    }
                }
                $result = Request-Clip -Platform "Twitch" -ItemName $itemName
                if ($result.Success) {
                    # Link clip to the most recent drop
                    if ($mostRecentIndex -ge 0) {
                        $script:Session.Drops[$mostRecentIndex].ClipUrl = $result.ClipUrl
                        $script:sessionDataDirty = $true; Save-SessionData
                    }
                    [System.Windows.Forms.Clipboard]::SetText($result.ClipUrl)
                    Update-ClipsList
                    Update-DropsGrid
                    [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip created and linked to: $itemName`nURL copied to clipboard!", "Clip Created")
                } else {
                    [System.Windows.Forms.MessageBox]::Show($script:MainForm, "Clip failed: $($result.Error)", "Clip Error")
                }
                $e.Handled = $true
            }
            $script:Config.QuickLogKey {
                Show-QuickDropDialog
                Update-DropsGrid
                Update-ItemList -Search $script:txtSearch.Text -Category $script:cmbCategory.Text -GameMode $script:cmbGameMode.Text -Boss $script:cmbBoss.Text
                $e.Handled = $true
            }
        }
    })
    
    # Apply theme
    Apply-Theme -Control $form
    
    # Populate boss filter dropdown with unique boss names
    if ($script:cmbBoss -and $script:BossDrops.Count -gt 0) {
        $script:cmbBoss.Items.Clear()
        [void]$script:cmbBoss.Items.Add("All")
        $uniqueBosses = $script:BossDrops | Select-Object -ExpandProperty BossName -Unique | Sort-Object
        foreach ($boss in $uniqueBosses) {
            [void]$script:cmbBoss.Items.Add($boss)
        }
        $script:cmbBoss.SelectedIndex = 0
    }
    
    # Load initial data
    Update-ItemList -Search "" -Category "All" -GameMode "All" -Boss "All"
    Update-DropsGrid
    Update-ScoreDisplay
    
    # Session Timer - updates every second
    $script:sessionUpdateTimer = New-Object System.Windows.Forms.Timer
    $script:sessionUpdateTimer.Interval = 1000  # 1 second
    $script:sessionSaveCounter = 0
    $script:gcCounter = 0
    $script:sessionUpdateTimer.Add_Tick({
        if ($script:SessionTimerRunning -and $script:SessionTimerStart) {
            $currentElapsed = (Get-Date) - $script:SessionTimerStart
            $totalTime = $script:SessionAccumulatedTime + $currentElapsed
            $script:lblSessionTimer.Text = "Session: {0:00}:{1:00}:{2:00}" -f [Math]::Floor($totalTime.TotalHours), $totalTime.Minutes, $totalTime.Seconds
            
            # Save every 30 seconds for overlay sync (overlay timer ticks locally)
            # Uses cached JSON with just timer value updated - very lightweight
            $script:sessionSaveCounter++
            if ($script:sessionSaveCounter -ge 30) {
                Save-SessionData
                $script:sessionSaveCounter = 0
            }
            
            # Garbage collection every 5 minutes to prevent memory buildup on long sessions
            $script:gcCounter++
            if ($script:gcCounter -ge 300) {
                [System.GC]::Collect([System.GC]::MaxGeneration, [System.GCCollectionMode]::Optimized)
                $script:gcCounter = 0
            }
        }
    })
    $script:sessionUpdateTimer.Start()
    
    return $form
    }
    catch {
        Write-Log "Error building form: $($_.Exception.Message)" -ForegroundColor Red
        Write-Log $_.ScriptStackTrace -ForegroundColor Red
        return $null
    }
}
#endregion

#region Main Execution
# Show splash screen during loading
Show-SplashScreen
Update-SplashStatus "Loading settings..."

# Load settings and session
Import-Settings
Import-SessionData

# Debug output
Write-Log "Session file: $($script:Config.SessionFile)" -ForegroundColor Cyan
Write-Log "Settings file: $($script:Config.SettingsFile)" -ForegroundColor Cyan
Write-Log "Player: $($script:Session.PlayerName), Score: $($script:Session.TotalScore), Drops: $($script:Session.Drops.Count)" -ForegroundColor Green
Write-Log "Twitch: $($script:Config.TwitchChannelName)" -ForegroundColor Green

# Load hunt data for selected game
Update-SplashStatus "Loading hunt data..."
$gameDataFile = Join-Path $script:AppDir $script:Config.GameDataFiles[$script:Config.SelectedGame]
if (Test-Path $gameDataFile) {
    $script:Config.DataFile = $gameDataFile
}
$dataLoaded = Import-HuntData -FilePath $script:Config.DataFile

if (-not $dataLoaded) {
    # Try loading from same directory as script (with updated filename)
    $altPath = Join-Path $script:AppDir "Hunt_BL4_2026_Updated.xlsx"
    if (Test-Path $altPath) {
        $script:Config.DataFile = $altPath
        $dataLoaded = Import-HuntData -FilePath $altPath
    }
    
    # Try original filename
    if (-not $dataLoaded) {
        $altPath2 = Join-Path $script:AppDir "Hunt_BL4_2026.xlsx"
        if (Test-Path $altPath2) {
            $script:Config.DataFile = $altPath2
            $dataLoaded = Import-HuntData -FilePath $altPath2
        }
    }
}

# Turn off silent mode now that initial load is done
$script:SilentLoad = $false

# If still no data, show error
if (-not $dataLoaded) {
    Close-SplashScreen
    [System.Windows.Forms.MessageBox]::Show(
        "Could not find Hunt data file.`n`nPlease place the hunt data file in the same folder as this app.`n`nExpected: $($script:Config.GameDataFiles[$script:Config.SelectedGame])`nLooking in: $script:AppDir`nFull path: $gameDataFile",
        "Data File Missing",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
}

# Start session if new
if (-not $script:Session.StartTime) {
    $script:Session.StartTime = Get-Date
}

# Track when THIS app session started (for elapsed time display)
$script:AppStartTime = Get-Date

# Skip first launch setup - no longer needed since player name was removed
# if (Test-FirstLaunch) {
#     Close-SplashScreen
#     $setupResult = Show-FirstLaunchSetup
#     if ($setupResult -ne [System.Windows.Forms.DialogResult]::OK) {
#         exit
#     }
# }

# Build and show main form
Update-SplashStatus "Building interface..."
try {
    $mainForm = Build-MainForm
    
    if ($null -eq $mainForm -or $mainForm -isnot [System.Windows.Forms.Form]) {
        throw "Failed to build main form - got type: $($mainForm.GetType().Name)"
    }
    
    # Update timer display if there's accumulated time from previous session
    if ($script:SessionAccumulatedTime.TotalSeconds -gt 0) {
        $script:lblSessionTimer.Text = "Session: {0:00}:{1:00}:{2:00}" -f [Math]::Floor($script:SessionAccumulatedTime.TotalHours), $script:SessionAccumulatedTime.Minutes, $script:SessionAccumulatedTime.Seconds
    }
    
    # Close splash and show the main form
    Close-SplashScreen
    [void]$mainForm.ShowDialog()
}
catch {
    Close-SplashScreen
    [System.Windows.Forms.MessageBox]::Show(
        "Error starting tracker: $($_.Exception.Message)`n`n$($_.ScriptStackTrace)",
        "Startup Error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    )
}

# Save on exit
$script:sessionDataDirty = $true; Save-SessionData
Save-Settings
#endregion
