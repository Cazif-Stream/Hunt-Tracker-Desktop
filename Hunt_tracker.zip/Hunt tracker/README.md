# The Hunt 2026 - BL4 Charity Event Tracker (Desktop Version)

The official desktop tracker for The Hunt 2026 Borderlands 4 charity event. Track your drops, create clips, sync with OBS, and submit directly to bl4hunt.com.

Download: [tracker.borderlandshunt.com](https://tracker.borderlandshunt.com)  
Web Version: [tracker.bl4hunt.com](https://tracker.bl4hunt.com)

---

## Installation

### Requirements

- Windows 10/11
- PowerShell 5.1+ (included with Windows)

### Setup

1. Download and extract the zip to a folder (e.g. `C:\Hunt Tracker\`)
2. Double-click `BL4_Hunt.exe` to launch

If Windows blocks the app: Right-click the EXE → Properties → Check "Unblock" → OK

### Files in the Package

| File | Required | Description |
|------|----------|-------------|
| BL4_Hunt.exe | Yes | The tracker application |
| Hunt_BL4_2026_Tiered.xlsx | Yes | Item database (197 items with point values) |
| hunt_logo.ico | Yes | App icon |
| hunt_logo.png | Optional | Logo displayed in the app header |
| Hunt_Stream_Overlay.html | Optional | Full OBS overlay (score, timer, drop list) |
| Hunt_Overlay_Compact.html | Optional | Compact overlay (logo, score, timer) |
| Hunt_Overlay_Score_Only.html | Optional | Score number only |
| BebasNeue-Regular.ttf | Optional | Custom font (falls back to Impact) |
| README.md | Optional | This file |

All files must be in the **same folder** as the EXE.

---

## Getting Started

### 1. Launch the Tracker

Double-click `BL4_Hunt.exe`. The app opens with the Drop Tracking tab showing all 197 Hunt items.

### 2. Connect Twitch

1. Click the **...** button (top right corner) to open Settings
2. Click **Connect Twitch**
3. A privacy notice explains what data is used — click Yes to continue
4. Your browser opens the Twitch authorization page
5. Log in and authorize the app
6. The tracker shows "Connected as: YourChannelName"

What Twitch connection does:
- Creates clips automatically when you record drops
- Opens the Twitch clip editor so you can rename the clip
- Copies the drop name to clipboard for easy pasting

What it does NOT do:
- Does not store your password or email
- Does not access your account settings
- Token is stored locally on your computer only
- Revoke access anytime at twitch.tv/settings/connections

### 3. Configure Auto-Clip (Recommended)

1. In Settings, check **Auto-clip on drop**
2. Now every time you record a drop, a Twitch clip is created and linked automatically

### 4. Start a Session

1. Click **START** to begin the session timer
2. Timer shows in the header and syncs to the OBS overlay
3. Click START again to pause, click **Reset** to clear the timer

---

## Recording Drops

### Single Drop
- Find the item in the list using Search, Type, Mode, or Boss filters
- Click **Record** next to the item, or select it and press **F5**
- If the item drops from multiple bosses, a source selector appears
- Each item can only be recorded **once** — duplicates are blocked

### Multiple Drops at Once
- Hold **Ctrl** and click to select multiple items in the grid
- Click **Record** or press **F5** to record all selected items at once
- If auto-clip is enabled, one clip is created and linked to all drops from that moment
- Any already-recorded items in the selection are skipped

---

## Creating and Managing Clips

### Automatic Clips (Recommended)
1. Enable **Auto-clip on drop** in Settings
2. When you record a drop while streaming, a clip is created automatically
3. The clip URL is linked to the drop
4. Twitch clip editor opens in your browser
5. Drop name is copied to clipboard — just Ctrl+V to rename the clip

### Manual Clip Creation
- Press **F6** or go to Clips tab → **Create Twitch Clip**
- The clip links to your most recent drop automatically

### Manually Linking a Clip
- Go to the Clips tab → **Link Clip to Drop**
- Select the drop that needs a clip
- Paste the clip URL (from Twitch, Kick, YouTube, etc.)

### Copying Clip URLs
- **Double-click** any clip in the list to copy its URL
- Or select a clip and click **Copy Selected URL**

---

## Submitting Drops to bl4hunt.com

1. Go to the **Export & Submit** tab
2. The status bar shows: Submitted / Ready / Missing Clips
3. Click **SUBMIT DROPS TO BL4HUNT.COM**
4. Make sure you are **logged in to bl4hunt.com** first
5. The tracker opens the item list page in your browser
6. For each unsubmitted drop with a clip:
   - The clip URL is automatically copied to your clipboard
   - A dialog shows the item name, boss, points, and instructions
   - On bl4hunt.com: find the item, click Claim, paste the clip URL (Ctrl+V), submit
   - Click **YES** in the tracker dialog after claiming → marks as submitted
   - Click **NO** to skip that drop
   - Click **CANCEL** to stop submitting
7. Already-submitted drops are automatically skipped

### Status Icons in the Points Column

| Display | Meaning |
|---------|---------|
| 3 | No clip attached |
| 3 [C] | Has clip, not yet submitted |
| 3 [OK] | Submitted to bl4hunt.com |

---

## Hotkeys

| Key | Action |
|-----|--------|
| F5 | Record selected drop(s) |
| F6 | Create Twitch clip |
| F7 | Quick Log (search popup to find and record items fast) |

Hotkeys work while the tracker is focused. Change them in Settings (**...** button).

---

## OBS Stream Overlay

Three overlay styles are included. All sync live with the tracker.

### Full Overlay (Hunt_Stream_Overlay.html)
Displays score, session timer, drop count, and a scrolling list of recent drops. Hunt-themed with maroon/gold colors and Bebas Neue font.

### Compact Overlay (Hunt_Overlay_Compact.html)
Small bar with the community logo, score, and timer. Good for a corner of your stream.

### Score Only (Hunt_Overlay_Score_Only.html)
Just the score number with no background. Fully transparent, position anywhere on your stream.

### Adding an Overlay to OBS

1. In OBS, click **+** under Sources → **Browser**
2. Check **Local file**
3. Browse to the overlay HTML file in your tracker folder
4. Set dimensions:
   - Full overlay: 400 x 600
   - Compact: 250 x 100
   - Score only: 180 x 70
5. Position and resize on your scene

### How Sync Works

The tracker writes `hunt_session.json` to the tracker folder every 2 seconds. The overlay reads this file to show live data.

- Score and timer refresh every **2 seconds**
- Drop list refreshes every **30 seconds** (prevents visual flashing)
- All overlay files must be in the **same folder** as the EXE

### Score Only Customization

Add URL parameters in the OBS Browser Source URL:

```
file:///C:/Hunt Tracker/Hunt_Overlay_Score_Only.html?size=64&mt=20&ml=10
```

| Param | Description | Default |
|-------|-------------|---------|
| size | Font size in pixels | 48 |
| mt | Margin top | 0 |
| mr | Margin right | 0 |
| mb | Margin bottom | 0 |
| ml | Margin left | 0 |
| m | All margins at once | 0 |

---

## Tabs

### Drop Tracking
- Full item list with all 197 Hunt items
- Search bar, Type/Mode/Boss filters
- Record button per item
- Multi-select with Ctrl+Click for simultaneous drops
- Drops grid showing session time, item, boss, points, and status
- Collected items highlighted in gold

### Clips
- Create Twitch Clip (F6) — creates and links automatically
- Kick Clip (Manual) — enter a Kick clip URL
- Link Clip to Drop — manually link any clip URL to a specific drop
- Copy Selected URL — copies the selected clip's URL
- Double-click any clip to copy its URL
- Full list of all recorded clips with platform, item name, and URL

### Export & Submit
- Export to JSON — full session backup (recommended after every session)
- Export to CSV — spreadsheet-friendly format with all drop data
- Clear Session — reset everything for a new session
- Submit to bl4hunt.com — browser-assisted submission flow
- Status counter showing Submitted / Ready / Missing Clips

---

## Settings

Click the **...** button in the top right corner.

### Twitch Connection
- Connect or disconnect your Twitch account
- Shows connection status
- Privacy notice displayed before first connection

### Clip Settings
- Auto-clip on drop — automatically creates a Twitch clip when you record a drop

### Hotkey Configuration
- Record Drop key (default: F5)
- Create Clip key (default: F6)
- Click the key field and press any key to reassign

---

## Data Files

The tracker creates these files in the same folder as the EXE:

| File | Description |
|------|-------------|
| hunt_session.json | Current session (drops, score, timer, clip links) |
| hunt_settings.json | Settings (Twitch token, hotkeys, auto-clip preference) |

Your session auto-saves every 2 seconds. Use **Export JSON** in the Export & Submit tab for additional backups.

---

## Troubleshooting

### App won't start
- Right-click the EXE → Properties → check "Unblock" → Apply
- Make sure `Hunt_BL4_2026_Tiered.xlsx` is in the same folder as the EXE
- Alternative: Use the included `Launch_Hunt_Tracker.bat` file instead

### Overlay not showing data
- The overlay HTML file must be in the same folder as the EXE
- Start the tracker and click START before checking the overlay
- Verify `hunt_session.json` exists in the folder
- In OBS Browser Source, make sure the file path is correct

### Twitch clips not working
- You must be currently live streaming on Twitch
- Check Settings to make sure Twitch shows as connected
- If authorization expired, disconnect and reconnect in Settings
- Check your internet connection

### Clips showing stream title instead of drop name
- This is a Twitch API limitation — clips always use the stream title
- The tracker opens the clip editor and copies the drop name to clipboard
- Just paste (Ctrl+V) to rename the clip on Twitch

---

## Credits

Built by Cazif Streaming for the Borderlands Community Fundraising Team.

- Hunt Website: [bl4hunt.com](https://www.bl4hunt.com)
- Web Tracker: [tracker.bl4hunt.com](https://tracker.bl4hunt.com)
- Desktop Download: [tracker.borderlandshunt.com](https://tracker.borderlandshunt.com)
